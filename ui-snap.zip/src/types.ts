export interface FamilyMember {
  id: string;
  name: string;
  relation: 'Self' | 'Spouse' | 'Mother' | 'Father' | 'Brother' | 'Sister' | 'Son' | 'Daughter' | 'Uncle' | 'Aunt' | 'Cousin' | 'Grandfather' | 'Grandmother' | 'Great Grandfather' | 'Great Grandmother' | 'Other';
  avatar?: string;
  birthYear?: number;
  isAlive: boolean;
  email?: string;
  phone?: string;
  location?: string;
  spouseId?: string;
  fatherId?: string;
  motherId?: string;
  bio?: string;
  deathYear?: number;
  memories?: { id: string; author: string; text: string; date: string }[];
}

export type ActiveTab = 'updates' | 'messages' | 'tree' | 'members' | 'gallery' | 'calendar' | 'memorial' | 'settings';

export interface FeedItem {
  id: string;
  title: string;
  content: string;
  author: string;
  date: string;
  category: 'announcement' | 'achievement' | 'milestone' | 'general';
  likes: number;
  comments: { id: string; author: string; text: string; date: string }[];
}

export interface Message {
  id: string;
  author: string;
  text: string;
  date: string;
  avatar?: string;
}

export interface GalleryItem {
  id: string;
  url: string;
  title: string;
  category: 'historical' | 'reunions' | 'candid' | 'nature';
  uploader: string;
  date: string;
  likes: number;
}

export interface CalendarEvent {
  id: string;
  title: string;
  date: string;
  time?: string;
  type: 'birthday' | 'anniversary' | 'reunion' | 'other';
  description?: string;
  location?: string;
  rsvps: { memberName: string; status: 'going' | 'maybe' | 'not_going' }[];
}

export interface Ancestor {
  id: string;
  name: string;
  birthYear: number;
  deathYear: number;
  role: string;
  portrait?: string;
  quote: string;
  bio: string;
  achievements: string[];
  candleCount: number;
  tributes: { id: string; author: string; avatar?: string; text: string; date: string }[];
}
