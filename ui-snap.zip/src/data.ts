// App data containing initial demo lists for tabs and fallback styling
export const IMAGES = {
  amma: '',
  distinguishedMan: '',
  suresh: '',
  priya: '',
  vikram: '',
  patriarch: '',
  calendarElder: '',
  galleryElders: '',
  weddingDress: '',
};

// Initial family announcements / feed
export const INITIAL_FEED: any[] = [];

// Initial family chat room messages
export const INITIAL_MESSAGES: any[] = [];

// Initial Shared Photo Gallery
export const INITIAL_GALLERY: any[] = [];

// Shared Family Calendar Events
export const INITIAL_EVENTS: any[] = [];

