import { useState, useEffect } from 'react';
import { 
  Home, 
  MessageSquare, 
  Settings, 
  Heart, 
  Network,
  Users
} from 'lucide-react';
import { ActiveTab } from './types';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import UpdatesTab from './components/UpdatesTab';
import MessagesTab from './components/MessagesTab';
import FamilyTreeTab from './components/FamilyTreeTab';
import MembersTab from './components/MembersTab';
import GalleryTab from './components/GalleryTab';
import CalendarTab from './components/CalendarTab';
import MemorialTab from './components/MemorialTab';
import SettingsTab from './components/SettingsTab';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>(() => {
    const saved = localStorage.getItem('family_active_tab') as ActiveTab;
    return saved && ['updates', 'messages', 'tree', 'members', 'gallery', 'calendar', 'memorial', 'settings'].includes(saved)
      ? saved
      : 'updates';
  });

  const [searchQuery, setSearchQuery] = useState('');
  
  // Dynamically load family surname from settings
  const [familySurname, setFamilySurname] = useState('Nimmagadda');

  useEffect(() => {
    localStorage.setItem('family_active_tab', activeTab);
  }, [activeTab]);

  useEffect(() => {
    const name = localStorage.getItem('family_settings_name');
    if (name) {
      setFamilySurname(name);
    }
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row text-slate-800">
      {/* 1. Sidebar Navigation (Hidden on Mobile, Visible on Desktop) */}
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* 2. Main Content Frame */}
      <div className="flex-1 flex flex-col min-w-0 max-w-7xl mx-auto w-full">
        {/* Header (Handles responsive searching and mobile toggle) */}
        <Header 
          searchQuery={searchQuery} 
          setSearchQuery={setSearchQuery} 
          activeTab={activeTab} 
          setActiveTab={setActiveTab} 
        />

        {/* Dynamic Title with Family Surname */}
        <div className="px-6 pt-4 shrink-0 flex items-center justify-between">
          <span className="font-serif text-slate-900 font-extrabold text-sm border-l-4 border-amber-500 pl-2.5">
            {familySurname} Shared Portal
          </span>
        </div>

        {/* Tab Switch Viewport */}
        <main className="flex-1 px-6 py-6 overflow-y-auto max-w-5xl w-full mx-auto">
          {activeTab === 'updates' && (
            <UpdatesTab searchQuery={searchQuery} />
          )}

          {activeTab === 'messages' && (
            <MessagesTab searchQuery={searchQuery} />
          )}

          {activeTab === 'tree' && (
            <FamilyTreeTab searchQuery={searchQuery} />
          )}

          {activeTab === 'members' && (
            <MembersTab searchQuery={searchQuery} />
          )}

          {activeTab === 'gallery' && (
            <GalleryTab searchQuery={searchQuery} />
          )}

          {activeTab === 'calendar' && (
            <CalendarTab searchQuery={searchQuery} />
          )}

          {activeTab === 'memorial' && (
            <MemorialTab searchQuery={searchQuery} />
          )}

          {activeTab === 'settings' && (
            <SettingsTab />
          )}
        </main>
      </div>

      {/* 3. Mobile Navigation Bar (Fixed bottom footer, visible on screens < md) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200/80 px-4 py-2 flex justify-around items-center z-40 shadow-xl select-none">
        <button 
          onClick={() => setActiveTab('updates')}
          className={`flex flex-col items-center justify-center py-1 flex-1 transition-all ${
            activeTab === 'updates' ? 'text-amber-600 font-extrabold scale-105' : 'text-slate-400 font-bold'
          }`}
        >
          <Home className="w-4 h-4 mb-0.5" />
          <span className="text-[9px] font-sans">Feed</span>
        </button>

        <button 
          onClick={() => setActiveTab('messages')}
          className={`flex flex-col items-center justify-center py-1 flex-1 transition-all ${
            activeTab === 'messages' ? 'text-amber-600 font-extrabold scale-105' : 'text-slate-400 font-bold'
          }`}
        >
          <MessageSquare className="w-4 h-4 mb-0.5" />
          <span className="text-[9px] font-sans">Chat</span>
        </button>

        <button 
          onClick={() => setActiveTab('tree')}
          className={`flex flex-col items-center justify-center py-1 flex-1 transition-all ${
            activeTab === 'tree' ? 'text-amber-600 font-extrabold scale-105' : 'text-slate-400 font-bold'
          }`}
        >
          <Network className="w-4 h-4 mb-0.5" />
          <span className="text-[9px] font-sans">Tree</span>
        </button>

        <button 
          onClick={() => setActiveTab('members')}
          className={`flex flex-col items-center justify-center py-1 flex-1 transition-all ${
            activeTab === 'members' ? 'text-amber-600 font-extrabold scale-105' : 'text-slate-400 font-bold'
          }`}
        >
          <Users className="w-4 h-4 mb-0.5" />
          <span className="text-[9px] font-sans">Members</span>
        </button>

        <button 
          onClick={() => setActiveTab('memorial')}
          className={`flex flex-col items-center justify-center py-1 flex-1 transition-all ${
            activeTab === 'memorial' ? 'text-amber-600 font-extrabold scale-105' : 'text-slate-400 font-bold'
          }`}
        >
          <Heart className="w-4 h-4 mb-0.5" />
          <span className="text-[9px] font-sans">Memories</span>
        </button>

        <button 
          onClick={() => setActiveTab('settings')}
          className={`flex flex-col items-center justify-center py-1 flex-1 transition-all ${
            activeTab === 'settings' ? 'text-amber-600 font-extrabold scale-105' : 'text-slate-400 font-bold'
          }`}
        >
          <Settings className="w-4 h-4 mb-0.5" />
          <span className="text-[9px] font-sans">Settings</span>
        </button>
      </nav>
    </div>
  );
}
