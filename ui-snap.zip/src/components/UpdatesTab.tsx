import { useState, useEffect } from 'react';
import { MessageCircle, Heart, PlusCircle, Check, BookOpen, AlertCircle } from 'lucide-react';
import { FeedItem } from '../types';
import { INITIAL_FEED } from '../data';

interface UpdatesTabProps {
  searchQuery: string;
}

export default function UpdatesTab({ searchQuery }: UpdatesTabProps) {
  const [feed, setFeed] = useState<FeedItem[]>(() => {
    const saved = localStorage.getItem('family_feed');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return INITIAL_FEED;
  });

  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [isAddOpen, setIsAddOpen] = useState(false);

  // Form State
  const [formTitle, setFormTitle] = useState('');
  const [formContent, setFormContent] = useState('');
  const [formAuthor, setFormAuthor] = useState('Vijay Nimmagadda');
  const [formCategory, setFormCategory] = useState<FeedItem['category']>('general');

  // Comment state per post
  const [newComments, setNewComments] = useState<{ [postId: string]: string }>({});

  useEffect(() => {
    localStorage.setItem('family_feed', JSON.stringify(feed));
  }, [feed]);

  const handleLike = (id: string) => {
    setFeed(prev => prev.map(item => {
      if (item.id === id) {
        return { ...item, likes: item.likes + 1 };
      }
      return item;
    }));
  };

  const handleAddComment = (postId: string, e: React.FormEvent) => {
    e.preventDefault();
    const text = newComments[postId]?.trim();
    if (!text) return;

    setFeed(prev => prev.map(item => {
      if (item.id === postId) {
        return {
          ...item,
          comments: [
            ...item.comments,
            {
              id: 'c-' + Date.now(),
              author: 'Vijay Nimmagadda',
              text,
              date: 'Just now'
            }
          ]
        };
      }
      return item;
    }));

    setNewComments(prev => ({ ...prev, [postId]: '' }));
  };

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formContent.trim()) return;

    const newPost: FeedItem = {
      id: 'feed-' + Date.now(),
      title: formTitle.trim(),
      content: formContent.trim(),
      author: formAuthor.trim() || 'Vijay Nimmagadda',
      date: new Date().toISOString().split('T')[0],
      category: formCategory,
      likes: 0,
      comments: []
    };

    setFeed(prev => [newPost, ...prev]);
    setIsAddOpen(false);
    
    // Reset Form
    setFormTitle('');
    setFormContent('');
    setFormCategory('general');
  };

  // Filter & Search
  const filteredFeed = feed.filter(item => {
    const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.author.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const getCategoryColor = (cat: FeedItem['category']) => {
    switch (cat) {
      case 'announcement': return 'bg-rose-50 text-rose-600 border-rose-200';
      case 'achievement': return 'bg-amber-50 text-amber-600 border-amber-200';
      case 'milestone': return 'bg-emerald-50 text-emerald-600 border-emerald-200';
      default: return 'bg-slate-50 text-slate-600 border-slate-200';
    }
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Banner */}
      <div className="bg-white border border-outline-variant/30 rounded-3xl p-6 sm:p-8 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="space-y-1.5 max-w-xl">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-rose-50 rounded-xl text-rose-600 border border-rose-200/50">
              <BookOpen className="w-5 h-5" />
            </span>
            <span className="font-sans text-[10px] font-black uppercase tracking-widest text-rose-600 bg-rose-50 px-2.5 py-1 rounded-md">Family Chronicle</span>
          </div>
          <h2 className="font-serif text-2xl font-black text-gray-900 tracking-tight">Announcements & Milestones</h2>
          <p className="font-sans text-xs text-on-surface-variant leading-relaxed">
            Stay up to date with family newsletters, proud graduation announcements, anniversaries, and community newsletters completely shared offline.
          </p>
        </div>
        <button
          onClick={() => setIsAddOpen(true)}
          className="w-full md:w-auto px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-sans text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 shadow-md transition-all cursor-pointer shrink-0"
        >
          <PlusCircle className="w-4 h-4 text-amber-400" />
          <span>Post Update</span>
        </button>
      </div>

      {/* Category Pills & Grid list */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200/60 pb-4">
        {['all', 'announcement', 'achievement', 'milestone', 'general'].map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-4 py-1.5 rounded-full font-sans text-xs font-bold capitalize transition-all cursor-pointer border ${
              activeCategory === cat
                ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'
            }`}
          >
            {cat === 'all' ? 'All Updates' : cat}
          </button>
        ))}
      </div>

      {/* Feed Columns */}
      <div className="max-w-3xl mx-auto space-y-6">
        {filteredFeed.map((item) => (
          <div key={item.id} className="bg-white border border-outline-variant/30 rounded-3xl p-6 shadow-xs hover:border-slate-300 transition-all space-y-4">
            
            {/* Post Header */}
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider border ${getCategoryColor(item.category)}`}>
                  {item.category}
                </span>
                <h3 className="font-serif text-base font-black text-slate-900 mt-2 leading-snug">{item.title}</h3>
                <p className="font-sans text-[10px] text-slate-400 font-bold mt-1">
                  Posted by <span className="text-slate-600">{item.author}</span> • {item.date}
                </p>
              </div>
            </div>

            {/* Post Content */}
            <p className="font-sans text-xs text-slate-700 leading-relaxed whitespace-pre-line">{item.content}</p>

            {/* Like Counter & Heart feedback */}
            <div className="flex items-center gap-4 pt-3 border-t border-slate-100">
              <button
                onClick={() => handleLike(item.id)}
                className="flex items-center gap-1.5 text-slate-500 hover:text-rose-600 transition-colors font-sans text-xs font-bold cursor-pointer group"
              >
                <Heart className="w-4 h-4 text-slate-400 group-hover:text-rose-500 group-hover:fill-rose-500 transition-all duration-300" />
                <span>{item.likes} {item.likes === 1 ? 'Like' : 'Likes'}</span>
              </button>
              <div className="flex items-center gap-1.5 text-slate-500 font-sans text-xs font-bold">
                <MessageCircle className="w-4 h-4 text-slate-400" />
                <span>{item.comments.length} {item.comments.length === 1 ? 'Comment' : 'Comments'}</span>
              </div>
            </div>

            {/* Comments List */}
            {item.comments.length > 0 && (
              <div className="bg-slate-50 rounded-2xl p-4 space-y-3.5 border border-slate-100">
                {item.comments.map((comment: any) => (
                  <div key={comment.id} className="text-xs space-y-0.5">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-800">{comment.author}</span>
                      <span className="text-[9px] text-slate-400">{comment.date}</span>
                    </div>
                    <p className="text-slate-600 font-medium leading-relaxed">{comment.text}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Add Comment Form */}
            <form onSubmit={(e) => handleAddComment(item.id, e)} className="flex gap-2 pt-1">
              <input
                type="text"
                placeholder="Write a warm comment..."
                value={newComments[item.id] || ''}
                onChange={(e) => setNewComments(prev => ({ ...prev, [item.id]: e.target.value }))}
                className="flex-1 bg-slate-50 border border-slate-200/80 focus:border-amber-400 rounded-xl px-3.5 py-2 text-xs font-medium outline-none transition-all"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-sans text-xs font-bold rounded-xl cursor-pointer transition-all shrink-0"
              >
                Reply
              </button>
            </form>
          </div>
        ))}

        {filteredFeed.length === 0 && (
          <div className="text-center py-16 bg-white border border-dashed border-slate-200 rounded-3xl p-6 text-slate-400">
            <AlertCircle className="w-8 h-8 mx-auto text-slate-300 mb-2" />
            <span className="font-sans text-xs font-semibold">No announcements or milestones match your active filter.</span>
          </div>
        )}
      </div>

      {/* CREATE POST MODAL DIALOG */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden border border-slate-100 flex flex-col max-h-[90vh] animate-fade-in">
            
            <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <div className="flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-rose-500" />
                <h3 className="font-serif text-base font-bold text-gray-900">Post Family Update</h3>
              </div>
              <button 
                onClick={() => setIsAddOpen(false)}
                className="p-1.5 rounded-full hover:bg-slate-200 text-slate-500 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePost} className="p-6 space-y-4">
              
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Category</label>
                <select
                  value={formCategory}
                  onChange={(e) => setFormCategory(e.target.value as FeedItem['category'])}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-3 py-2.5 text-xs font-medium outline-none"
                >
                  <option value="general">General Chat</option>
                  <option value="announcement">Announcement</option>
                  <option value="achievement">Achievement</option>
                  <option value="milestone">Milestone</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Title *</label>
                <input
                  type="text"
                  required
                  placeholder="What is happening in the family?"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-4 py-2.5 text-xs font-medium outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Content / Details *</label>
                <textarea
                  rows={4}
                  required
                  placeholder="Share details here... Everyone in the family tree registry can read it."
                  value={formContent}
                  onChange={(e) => setFormContent(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-4 py-2.5 text-xs font-medium outline-none resize-none"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Author</label>
                <input
                  type="text"
                  placeholder="Your Name"
                  value={formAuthor}
                  onChange={(e) => setFormAuthor(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-4 py-2.5 text-xs font-medium outline-none"
                />
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-sans text-xs font-bold rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-sans text-xs font-bold rounded-xl cursor-pointer flex items-center gap-1"
                >
                  <Check className="w-3.5 h-3.5 text-amber-400" />
                  <span>Post Update</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}

// Minimal placeholder Close icon
function X(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <line x1="18" y1="6" x2="6" y2="18"></line>
      <line x1="6" y1="6" x2="18" y2="18"></line>
    </svg>
  );
}
