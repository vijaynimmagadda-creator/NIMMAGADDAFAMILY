import { useState, useEffect, useRef } from 'react';
import { 
  Send, 
  MessageSquare, 
  Trash2, 
  Phone, 
  Video, 
  PhoneOff, 
  Mic, 
  MicOff, 
  Volume2 as SpeakerIcon, 
  VolumeX, 
  VideoOff, 
  Clock, 
  PhoneCall, 
  Radio,
  CheckCheck,
  Smartphone,
  ChevronLeft
} from 'lucide-react';
import { Message } from '../types';

interface MessagesTabProps {
  searchQuery: string;
}

interface Contact {
  id: string;
  name: string;
  relation: string;
  avatar: string;
  avatarColor: string;
  status: 'Online' | 'Active 5m ago' | 'Offline' | 'Active 10m ago';
  bio: string;
  quickPrompts: string[];
}

const CONTACTS: Contact[] = [
  { 
    id: 'general', 
    name: 'Nimmagadda Family Board', 
    relation: 'Shared Board', 
    avatar: '👥', 
    avatarColor: 'from-amber-400 to-amber-600',
    status: 'Online', 
    bio: 'The common room for all family announcements and general chat.',
    quickPrompts: ['Who is attending the reunion in Vizag?', 'Check out the new Family Tree diagram!']
  },
  { 
    id: 'amma', 
    name: 'Amma (Sita Nimmagadda)', 
    relation: 'Mother', 
    avatar: '🌸', 
    avatarColor: 'from-rose-400 to-pink-600',
    status: 'Online', 
    bio: 'Avid organic gardener & family coordinator in Visakhapatnam.',
    quickPrompts: ['Amma, how is your organic garden doing?', 'What are you cooking for dinner?']
  },
  { 
    id: 'priya', 
    name: 'Priya Nimmagadda', 
    relation: 'Sister', 
    avatar: '💻', 
    avatarColor: 'from-sky-400 to-blue-600',
    status: 'Active 5m ago', 
    bio: 'Software architect based in San Jose, CA.',
    quickPrompts: ['Priya, how was your code sprint?', 'Are you joining our Vizag flight?']
  },
  { 
    id: 'suresh', 
    name: 'Suresh Nimmagadda', 
    relation: 'Uncle', 
    avatar: '♟️', 
    avatarColor: 'from-teal-400 to-emerald-600',
    status: 'Online', 
    bio: 'Senior chess mentor based in Bangalore, India.',
    quickPrompts: ['Uncle Suresh, let’s play chess!', 'How is the chess tournament going?']
  },
  { 
    id: 'vikram', 
    name: 'Vikram Nimmagadda', 
    relation: 'Brother', 
    avatar: '📚', 
    avatarColor: 'from-violet-400 to-purple-600',
    status: 'Active 10m ago', 
    bio: 'MA Historical Research Student at UCL, London.',
    quickPrompts: ['Hey Vikram! How is UCL?', 'Did you find any old family archives?']
  }
];

// Pure Web Audio API tone generator for calling sounds (Dial tone, Ringing, Connect, Hangup)
const playTone = (type: 'dial' | 'ring' | 'connect' | 'hangup') => {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();

    if (type === 'dial') {
      // Short dual-tone
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();
      osc1.frequency.setValueAtTime(350, ctx.currentTime);
      osc2.frequency.setValueAtTime(440, ctx.currentTime);
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);
      osc1.start();
      osc2.start();
      osc1.stop(ctx.currentTime + 0.3);
      osc2.stop(ctx.currentTime + 0.3);
    } else if (type === 'ring') {
      // Intermittent telephone ring (440Hz + 480Hz modulated)
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();
      osc1.frequency.setValueAtTime(440, ctx.currentTime);
      osc2.frequency.setValueAtTime(480, ctx.currentTime);
      
      gain.gain.setValueAtTime(0.05, ctx.currentTime);
      gain.gain.setValueAtTime(0.05, ctx.currentTime + 0.4);
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.5);
      
      gain.gain.setValueAtTime(0.05, ctx.currentTime + 0.7);
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 1.2);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);
      osc1.start();
      osc2.start();
      osc1.stop(ctx.currentTime + 1.4);
      osc2.stop(ctx.currentTime + 1.4);
    } else if (type === 'connect') {
      // Friendly melodic ascending chord
      [329.63, 392.00, 523.25].forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.08);
        gain.gain.setValueAtTime(0.06, ctx.currentTime + idx * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.08 + 0.25);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + idx * 0.08);
        osc.stop(ctx.currentTime + idx * 0.08 + 0.3);
      });
    } else if (type === 'hangup') {
      // Descending pitch
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.setValueAtTime(261.63, ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(130.81, ctx.currentTime + 0.4);
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.4);
    }
  } catch (err) {
    console.warn('Sound playback blocked or unsupported', err);
  }
};

export default function MessagesTab({ searchQuery }: MessagesTabProps) {
  // Active selected room state
  const [activeRoomId, setActiveRoomId] = useState<string>(() => {
    return localStorage.getItem('family_active_room_id') || 'general';
  });

  // Track threads in state, initialized from localStorage
  const [threads, setThreads] = useState<Record<string, Message[]>>(() => {
    const saved = localStorage.getItem('family_chat_threads');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }

    // Default messages per room
    return {
      general: [
        { id: 'gen-1', author: 'Suresh Nimmagadda', text: 'Good morning everyone! Hope everyone in Hyderabad and San Jose is doing well.', date: '08:30 AM' },
        { id: 'gen-2', author: 'Priya Nimmagadda', text: 'Morning Uncle! Just finished a long work sprint here. It is late evening in California.', date: '08:32 AM' },
        { id: 'gen-3', author: 'Vijay Nimmagadda', text: 'Hey Priya, Suresh! I just pushed updates to our Family Tree tab. Let me know if the mother/father nodes show up correctly.', date: '08:35 AM' },
        { id: 'gen-4', author: 'Amma (Sita Nimmagadda)', text: 'Hello children! Vijay, the tree looks wonderful. So easy to see how Suresh and I are connected to grandfather.', date: '08:42 AM' }
      ],
      amma: [
        { id: 'amm-1', author: 'Amma (Sita Nimmagadda)', text: 'Hello beta! Have you had lunch yet? I completed the weeding in our mango grove today.', date: 'Yesterday' },
        { id: 'amm-2', author: 'Vijay Nimmagadda', text: 'Yes Amma, ate some curd rice. Garden is looking wonderful!', date: 'Yesterday' }
      ],
      priya: [
        { id: 'pri-1', author: 'Priya Nimmagadda', text: 'Vijay, can you double check grandfather’s birth year on the tree? I think it was 1928, not 1930.', date: '2 days ago' },
        { id: 'pri-2', author: 'Vijay Nimmagadda', text: 'Sure Priya! I will research it in Savitri grandmother’s diary.', date: '2 days ago' }
      ],
      suresh: [
        { id: 'sur-1', author: 'Suresh Nimmagadda', text: 'Vijay, our next family chess game is pending! Get ready to defend your knight.', date: '3 days ago' }
      ],
      vikram: [
        { id: 'vik-1', author: 'Vikram Nimmagadda', text: 'Bro! London is brilliant! Visited the British Library today. Found some early 20th-century maps of Andhra spice trades.', date: '4 days ago' }
      ]
    };
  });

  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState<string | null>(null); // Contact ID who is typing
  const [mobileShowList, setMobileShowList] = useState(true);

  // Call System State
  const [callState, setCallState] = useState<{
    contactId: string;
    type: 'voice' | 'video';
    status: 'ringing' | 'connected' | 'ended' | 'incoming';
    duration: number;
    muted: boolean;
    speaker: boolean;
    cameraOn: boolean;
  } | null>(null);

  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const ringingIntervalRef = useRef<any>(null);

  // Sync rooms and threads
  useEffect(() => {
    localStorage.setItem('family_chat_threads', JSON.stringify(threads));
    localStorage.setItem('family_active_room_id', activeRoomId);
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [threads, activeRoomId]);

  // Handle active call timers
  useEffect(() => {
    let timer: any;
    if (callState && callState.status === 'connected') {
      timer = setInterval(() => {
        setCallState(prev => {
          if (!prev) return null;
          return { ...prev, duration: prev.duration + 1 };
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [callState?.status]);

  // Periodic ringing tone
  useEffect(() => {
    if (callState && (callState.status === 'ringing' || callState.status === 'incoming')) {
      playTone('ring');
      ringingIntervalRef.current = setInterval(() => {
        playTone('ring');
      }, 2500);
    } else {
      if (ringingIntervalRef.current) {
        clearInterval(ringingIntervalRef.current);
        ringingIntervalRef.current = null;
      }
    }
    return () => {
      if (ringingIntervalRef.current) clearInterval(ringingIntervalRef.current);
    };
  }, [callState?.status]);

  // Access camera stream during Video connected state
  useEffect(() => {
    if (callState && callState.status === 'connected' && callState.type === 'video' && callState.cameraOn) {
      navigator.mediaDevices.getUserMedia({ video: true, audio: true })
        .then(stream => {
          setLocalStream(stream);
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = stream;
          }
        })
        .catch(err => {
          console.warn("Could not capture webcam stream (permission blocked or no webcam):", err);
        });
    } else {
      if (localStream) {
        localStream.getTracks().forEach(track => track.stop());
        setLocalStream(null);
      }
    }
  }, [callState?.status, callState?.type, callState?.cameraOn]);

  // Formulate automatic responses from family members (personally crafted)
  const triggerAutoReply = (roomId: string, userMsg: string) => {
    if (roomId === 'general') return; // Only direct 1-to-1 rooms trigger automated direct chats

    setIsTyping(roomId);

    setTimeout(() => {
      let replyText = '';
      const lower = userMsg.toLowerCase();

      if (roomId === 'amma') {
        if (lower.includes('hello') || lower.includes('hi') || lower.includes('amma')) {
          replyText = "Hello beta! I am sitting on the swing in the courtyard thinking of you. Did you sleep enough? Take proper care of your health.";
        } else if (lower.includes('food') || lower.includes('curd') || lower.includes('cook') || lower.includes('eat') || lower.includes('lunch') || lower.includes('dinner')) {
          replyText = "Ah! I made standard coconut chutney and hot idlis this morning. Please make sure you don't eat outside junk food constantly. Drink plenty of warm water!";
        } else if (lower.includes('garden') || lower.includes('mango') || lower.includes('tree') || lower.includes('organic')) {
          replyText = "My white jasmine flower hedge is full of buds today! The fragrance is lovely. I also spotted two small green mangoes on the seedling you bought me!";
        } else if (lower.includes('tree') || lower.includes('family') || lower.includes('ancestor') || lower.includes('grandfather')) {
          replyText = "Grandfather Ramachandra was a noble man. He always kept his diary in the desk. I am so happy you are making this tree to keep us together.";
        } else if (lower.includes('call') || lower.includes('phone') || lower.includes('video')) {
          replyText = "Sure beta! I would love to see your beautiful face. Click that video icon above, or let me know when you are free to pick up.";
        } else {
          replyText = "That is sweet of you to share, Vijay. Bless you! Let's talk more soon.";
        }
      } else if (roomId === 'priya') {
        if (lower.includes('hello') || lower.includes('hi')) {
          replyText = "Hey Vijay! What's up? Just wrapping up a long project sprint. How is Hyderabad weather?";
        } else if (lower.includes('code') || lower.includes('design') || lower.includes('sprint') || lower.includes('react') || lower.includes('tech')) {
          replyText = "Nice! Actually our team is moving to a Tailwind styling system too. Your family tree design is really slick, love the smooth connections.";
        } else if (lower.includes('reunion') || lower.includes('flight') || lower.includes('vizag')) {
          replyText = "Oh, absolutely. I booked my ticket from SFO to Vizag for Dec 18. Priya is fully ready! I'll buy some dry fruits from San Jose for everyone.";
        } else {
          replyText = "Makes total sense. Let me jump on our family calendar to add the reminders.";
        }
      } else if (roomId === 'suresh') {
        if (lower.includes('hello') || lower.includes('hi') || lower.includes('uncle')) {
          replyText = "Greetings Vijay! Good morning from Bangalore. I was just reading the morning newspaper.";
        } else if (lower.includes('chess') || lower.includes('game') || lower.includes('play')) {
          replyText = "Ah! I played a classical French Defense tournament yesterday. Let me know when you have 15 minutes, we will start a digital chess board!";
        } else if (lower.includes('reunion') || lower.includes('vizag')) {
          replyText = "Visakhapatnam reunion will be golden. We must organize a grand sitar evening by the coast.";
        } else {
          replyText = "Excellent. I appreciate you updating me. Warm regards to everyone.";
        }
      } else if (roomId === 'vikram') {
        if (lower.includes('hello') || lower.includes('hi') || lower.includes('bro')) {
          replyText = "Hey bro! What is the news? London is absolutely freezing but lovely.";
        } else if (lower.includes('study') || lower.includes('ucl') || lower.includes('history') || lower.includes('archives')) {
          replyText = "My MA classes are intense but brilliant! Currently compiling old land registries from Savitri grandmother's ancestral towns. Found incredible records!";
        } else {
          replyText = "Brilliant! Tell Amma I am buying her a classical English woolen shawl from London.";
        }
      }

      const replyMsg: Message = {
        id: 'reply-' + Date.now(),
        author: CONTACTS.find(c => c.id === roomId)?.name || 'Relative',
        text: replyText,
        date: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setThreads(prev => ({
        ...prev,
        [roomId]: [...(prev[roomId] || []), replyMsg]
      }));

      setIsTyping(null);
    }, 1800);
  };

  const handleSendMessage = (e?: React.FormEvent, customText?: string) => {
    if (e) e.preventDefault();
    const textToSend = customText !== undefined ? customText : inputText;
    if (!textToSend.trim()) return;

    const newMessage: Message = {
      id: 'msg-' + Date.now(),
      author: 'Vijay Nimmagadda',
      text: textToSend.trim(),
      date: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setThreads(prev => ({
      ...prev,
      [activeRoomId]: [...(prev[activeRoomId] || []), newMessage]
    }));

    if (customText === undefined) {
      setInputText('');
    }

    triggerAutoReply(activeRoomId, textToSend);
  };

  const handleClearThread = () => {
    const contactName = CONTACTS.find(c => c.id === activeRoomId)?.name || 'this room';
    if (confirm(`Clear chat history with ${contactName}? This is permanent.`)) {
      setThreads(prev => ({
        ...prev,
        [activeRoomId]: []
      }));
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .filter(n => n.length > 0 && !n.startsWith('('))
      .map(n => n[0])
      .slice(0, 2)
      .join('')
      .toUpperCase() || 'FM';
  };

  // Triggering calls
  const initiateCall = (type: 'voice' | 'video') => {
    if (activeRoomId === 'general') return;
    playTone('dial');
    setCallState({
      contactId: activeRoomId,
      type,
      status: 'ringing',
      duration: 0,
      muted: false,
      speaker: true,
      cameraOn: type === 'video',
    });

    // Automatically simulate connection after 3 seconds of ringing
    setTimeout(() => {
      setCallState(prev => {
        if (!prev || prev.status !== 'ringing') return prev;
        playTone('connect');
        return { ...prev, status: 'connected' };
      });
    }, 3200);
  };

  const simulateIncomingCall = (contactId: string, type: 'voice' | 'video' = 'video') => {
    setCallState({
      contactId,
      type,
      status: 'incoming',
      duration: 0,
      muted: false,
      speaker: true,
      cameraOn: type === 'video',
    });
  };

  const acceptCall = () => {
    playTone('connect');
    setCallState(prev => {
      if (!prev) return null;
      return { ...prev, status: 'connected' };
    });
  };

  const endCall = () => {
    playTone('hangup');
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
      setLocalStream(null);
    }
    setCallState(prev => {
      if (!prev) return null;
      return { ...prev, status: 'ended' };
    });

    setTimeout(() => {
      setCallState(null);
    }, 1500);
  };

  const formatTimer = (sec: number) => {
    const m = Math.floor(sec / 60).toString().padStart(2, '0');
    const s = (sec % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  const currentContact = CONTACTS.find(c => c.id === activeRoomId) || CONTACTS[0];
  const activeMessages = threads[activeRoomId] || [];

  const filteredMessages = activeMessages.filter(msg =>
    !searchQuery ||
    msg.text.toLowerCase().includes(searchQuery.toLowerCase()) ||
    msg.author.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="relative h-[calc(100vh-140px)] bg-slate-50 border border-slate-200/60 rounded-3xl overflow-hidden flex shadow-sm animate-fade-in">
      
      {/* 1. ROOMS / CONTACTS LIST (LEFT COLUMN) */}
      <div className={`w-full md:w-80 bg-white border-r border-slate-100 flex flex-col h-full shrink-0 ${
        mobileShowList ? 'block' : 'hidden md:flex'
      }`}>
        <div className="p-4 border-b border-slate-100 bg-slate-50 shrink-0 flex items-center justify-between">
          <div>
            <h3 className="font-serif text-sm font-black text-slate-900">Family Chats</h3>
            <p className="font-sans text-[10px] text-slate-400 font-bold uppercase tracking-widest">5 Channels online</p>
          </div>
          
          {/* Quick Trigger to Receive a simulated Incoming Call */}
          <button
            onClick={() => simulateIncomingCall('amma', 'video')}
            className="px-2 py-1 bg-amber-500 hover:bg-amber-600 text-slate-950 font-sans text-[9px] font-black rounded-lg cursor-pointer flex items-center gap-1 transition-all shadow-xs"
            title="Simulate incoming video call from Amma"
          >
            <PhoneCall className="w-2.5 h-2.5" />
            <span>Simulate Call</span>
          </button>
        </div>

        {/* Contacts Stream */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-100/60 p-2 space-y-1">
          {CONTACTS.map(contact => {
            const isActive = activeRoomId === contact.id;
            const lastMsg = threads[contact.id]?.[threads[contact.id]?.length - 1];
            
            return (
              <button
                key={contact.id}
                onClick={() => {
                  setActiveRoomId(contact.id);
                  setMobileShowList(false);
                }}
                className={`w-full p-3 rounded-2xl flex gap-3 text-left transition-all relative cursor-pointer group ${
                  isActive 
                    ? 'bg-slate-900 text-white shadow-md' 
                    : 'hover:bg-slate-50 text-slate-800'
                }`}
              >
                {/* Visual Avatar */}
                <div className="relative shrink-0 select-none">
                  <div className={`w-11 h-11 rounded-full flex items-center justify-center text-lg bg-gradient-to-br shadow-inner ${
                    isActive ? 'from-amber-300 to-amber-500 text-slate-950' : contact.avatarColor + ' text-white'
                  }`}>
                    {contact.avatar}
                  </div>
                  <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full" />
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <span className={`font-serif text-xs font-bold leading-tight truncate ${
                      isActive ? 'text-amber-400' : 'text-slate-900'
                    }`}>
                      {contact.name}
                    </span>
                    <span className="font-sans text-[8px] text-slate-400 shrink-0 uppercase tracking-widest">
                      {contact.relation}
                    </span>
                  </div>

                  <p className={`font-sans text-[11px] truncate mt-1 leading-snug ${
                    isActive ? 'text-slate-300' : 'text-slate-500'
                  }`}>
                    {lastMsg ? lastMsg.text : 'No conversations yet. Tap to chat!'}
                  </p>

                  <div className="flex items-center gap-1 mt-1">
                    <span className={`font-sans text-[9px] font-semibold ${
                      isActive ? 'text-amber-500/80' : 'text-slate-400'
                    }`}>
                      {contact.status}
                    </span>
                  </div>
                </div>

                {/* Left line decoration */}
                {isActive && (
                  <div className="absolute left-0 top-3 bottom-3 w-1 bg-amber-400 rounded-r-md" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. MAIN ACTIVE CONVERSATION CONTEXT WINDOW */}
      <div className={`flex-1 flex flex-col h-full bg-white relative ${
        !mobileShowList ? 'block' : 'hidden md:flex'
      }`}>
        
        {/* Active conversation Header */}
        <div className="px-5 py-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between shrink-0 gap-3">
          
          {/* Contact Identifier */}
          <div className="flex items-center gap-3 min-w-0">
            {/* Mobile Back Button */}
            <button
              onClick={() => setMobileShowList(true)}
              className="md:hidden p-1.5 hover:bg-slate-200/50 rounded-lg text-slate-600 cursor-pointer"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            <div className="relative shrink-0 select-none">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center text-base bg-gradient-to-br shadow-inner text-white ${currentContact.avatarColor}`}>
                {currentContact.avatar}
              </div>
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 border-2 border-white rounded-full" />
            </div>

            <div className="min-w-0">
              <h4 className="font-serif text-xs font-black text-slate-900 leading-snug truncate">
                {currentContact.name}
              </h4>
              <p className="font-sans text-[10px] text-slate-400 font-bold uppercase tracking-wider flex items-center gap-1">
                <span>{currentContact.relation}</span>
                <span>•</span>
                <span className="text-green-600">{currentContact.status}</span>
              </p>
            </div>
          </div>

          {/* Interactive Calling and Control Actions */}
          {activeRoomId !== 'general' && (
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                onClick={() => initiateCall('voice')}
                className="p-2.5 bg-sky-50 hover:bg-sky-100 text-sky-700 rounded-xl cursor-pointer hover:scale-105 transition-all border border-sky-100 flex items-center gap-1.5"
                title="Initiate Secure Voice Call"
              >
                <Phone className="w-4 h-4" />
                <span className="hidden sm:inline font-sans text-[10px] font-black uppercase tracking-wider">Voice</span>
              </button>
              
              <button
                onClick={() => initiateCall('video')}
                className="p-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl cursor-pointer hover:scale-105 transition-all border border-rose-100 flex items-center gap-1.5"
                title="Initiate Live Video Call"
              >
                <Video className="w-4 h-4" />
                <span className="hidden sm:inline font-sans text-[10px] font-black uppercase tracking-wider">Video Call</span>
              </button>

              <button
                onClick={handleClearThread}
                className="p-2 bg-slate-50 hover:bg-red-50 text-slate-400 hover:text-red-500 rounded-xl cursor-pointer border border-slate-200/50"
                title="Clear Conversation Stream"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

        {/* Message Stream Scroll */}
        <div className="flex-1 bg-slate-50/20 p-6 overflow-y-auto space-y-4">
          
          {/* Biography Intro banner inside thread */}
          {currentContact.id !== 'general' && (
            <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200/30 rounded-2xl p-4 max-w-xl mx-auto text-center space-y-1 shadow-xs mb-6">
              <p className="font-serif text-xs font-bold text-amber-900">{currentContact.name}</p>
              <p className="font-sans text-[11px] text-slate-600 leading-normal italic">
                "{currentContact.bio}"
              </p>
              <div className="pt-2 flex justify-center gap-2 flex-wrap">
                <span className="text-[9px] bg-white text-slate-500 px-2.5 py-0.5 rounded-full font-bold border border-slate-100 uppercase tracking-widest flex items-center gap-1">
                  <Smartphone className="w-2.5 h-2.5" /> Mobile Online
                </span>
                <span className="text-[9px] bg-white text-slate-500 px-2.5 py-0.5 rounded-full font-bold border border-slate-100 uppercase tracking-widest flex items-center gap-1">
                  <Radio className="w-2.5 h-2.5 text-green-500 animate-pulse" /> HD Voice Supported
                </span>
              </div>
            </div>
          )}

          {filteredMessages.map((msg) => {
            const isMe = msg.author === 'Vijay Nimmagadda';
            const authorContact = CONTACTS.find(c => c.name === msg.author);

            return (
              <div
                key={msg.id}
                className={`flex items-start gap-3 max-w-md ${
                  isMe ? 'ml-auto flex-row-reverse' : 'mr-auto'
                }`}
              >
                {/* initials or icon */}
                <div className={`w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center font-sans font-black text-[10px] select-none text-white ${
                  isMe 
                    ? 'bg-slate-900' 
                    : (authorContact ? authorContact.avatarColor : 'bg-slate-400')
                }`}>
                  {isMe ? 'VJ' : (authorContact ? authorContact.avatar : getInitials(msg.author))}
                </div>

                <div className="space-y-1">
                  <div className={`flex items-center gap-2 ${isMe ? 'justify-end' : ''}`}>
                    <span className="font-sans text-[10px] font-extrabold text-slate-800">{msg.author}</span>
                    <span className="font-mono text-[9px] text-slate-400">{msg.date}</span>
                  </div>

                  <div className={`px-4 py-2.5 rounded-2xl text-xs font-medium leading-relaxed shadow-xs ${
                    isMe 
                      ? 'bg-slate-900 text-white rounded-tr-none' 
                      : 'bg-white border border-slate-200/80 text-slate-800 rounded-tl-none'
                  }`}>
                    <p className="whitespace-pre-line">{msg.text}</p>
                    
                    {isMe && (
                      <div className="flex justify-end gap-0.5 mt-1 text-[9px] text-amber-400 font-bold">
                        <span>Sent</span>
                        <CheckCheck className="w-3 h-3 text-amber-400 shrink-0" />
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          {/* Contact is typing Indicator */}
          {isTyping === activeRoomId && (
            <div className="flex items-center gap-3 max-w-xs mr-auto">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs text-white ${currentContact.avatarColor}`}>
                {currentContact.avatar}
              </div>
              <div className="bg-white border border-slate-200/70 p-3 rounded-2xl rounded-tl-none shadow-xs flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          )}

          {filteredMessages.length === 0 && !isTyping && (
            <div className="text-center py-20 text-slate-400 max-w-sm mx-auto">
              <MessageSquare className="w-8 h-8 mx-auto text-slate-300 mb-2" />
              <span className="font-sans text-xs font-semibold block text-slate-800">Your thread with {currentContact.name} is empty.</span>
              <p className="font-sans text-[11px] text-slate-500 mt-1">Type a loving family memo below or choose one of our helpful quick prompts!</p>
            </div>
          )}

          <div ref={chatEndRef} />
        </div>

        {/* Quick Prompts Helper */}
        {currentContact.quickPrompts && currentContact.quickPrompts.length > 0 && (
          <div className="px-5 py-2.5 bg-slate-50 border-t border-slate-100 flex gap-2 overflow-x-auto whitespace-nowrap shrink-0 scrollbar-none">
            <span className="font-sans text-[9px] text-slate-400 font-bold uppercase tracking-wider self-center mr-1">Suggested:</span>
            {currentContact.quickPrompts.map((promptText, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(undefined, promptText)}
                className="px-3 py-1 bg-white hover:bg-amber-50 hover:text-amber-700 text-slate-600 border border-slate-200 text-[10px] font-bold rounded-full transition-all cursor-pointer shrink-0"
              >
                {promptText}
              </button>
            ))}
          </div>
        )}

        {/* Input Text Form */}
        <form onSubmit={(e) => handleSendMessage(e)} className="bg-white border-t border-slate-100 p-4 flex gap-3 shadow-md shrink-0 items-center">
          <input
            type="text"
            placeholder={`Type a loving message to ${currentContact.name}...`}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            className="flex-1 bg-slate-50 border border-slate-200/80 focus:border-amber-400 rounded-2xl px-4 py-3 text-xs font-semibold text-slate-800 outline-none focus:bg-white transition-all"
          />
          <button
            type="submit"
            className="px-5 py-3 bg-slate-900 hover:bg-slate-800 text-amber-400 font-sans text-xs font-black rounded-2xl flex items-center justify-center gap-1.5 transition-all shadow-md shrink-0 cursor-pointer"
          >
            <span>Send</span>
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>

      {/* 3. FULL SCREEN INTERACTIVE CALL SCREEN (OVERLAY MODAL) */}
      {callState && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-950 p-4 text-white overflow-hidden font-sans">
          
          {/* Subtle cosmic background grid and ambient lighting */}
          <div className="absolute inset-0 bg-radial-at-t from-slate-900 via-slate-950 to-black opacity-90 z-0" />
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-rose-500/10 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-sky-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />

          {/* Interactive Calling Frame */}
          <div className="relative z-10 w-full max-w-lg h-full max-h-[85vh] flex flex-col justify-between items-center px-6 py-8">
            
            {/* Header / Security Status */}
            <div className="w-full flex items-center justify-between text-[10px] font-mono tracking-wider text-slate-400 border-b border-white/10 pb-4">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 bg-green-500 rounded-full animate-ping" />
                <span className="uppercase text-green-400 font-bold">End-to-End Encrypted</span>
              </div>
              <div className="flex items-center gap-1">
                <span>96kbps</span>
                <span>•</span>
                <span>Opus HD</span>
              </div>
            </div>

            {/* Simulated Live Video / Avatar Showcase container */}
            <div className="w-full flex-1 flex flex-col justify-center items-center relative my-6 min-h-[280px]">
              
              {/* VIDEO CALL SCREEN */}
              {callState.type === 'video' && callState.status === 'connected' ? (
                <div className="w-full h-full bg-slate-900 border border-white/10 rounded-3xl overflow-hidden relative shadow-2xl flex items-center justify-center">
                  
                  {/* Remote Simulated Live video loop */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 bg-gradient-to-b from-slate-900/60 via-slate-900 to-slate-950">
                    
                    {/* Pulsing visual aura */}
                    <div className="absolute w-44 h-44 rounded-full border border-rose-500/30 animate-ping opacity-60" />
                    
                    <div className="relative mb-4">
                      <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-amber-300 to-pink-500 flex items-center justify-center text-4xl shadow-2xl select-none">
                        {CONTACTS.find(c => c.id === callState.contactId)?.avatar || '🌸'}
                      </div>
                      <span className="absolute bottom-1 right-1 w-6 h-6 bg-green-500 border-4 border-slate-900 rounded-full" />
                    </div>

                    <h3 className="font-serif text-lg font-bold text-white tracking-wide">
                      {CONTACTS.find(c => c.id === callState.contactId)?.name}
                    </h3>
                    <p className="text-[10px] text-rose-400 font-bold tracking-widest uppercase mt-1">Live Simulated Video Connection</p>
                    
                    {/* Telemetry metadata overlay */}
                    <div className="mt-4 grid grid-cols-2 gap-x-6 gap-y-1.5 text-[9px] font-mono text-slate-400 bg-black/40 backdrop-blur-md p-3 rounded-2xl border border-white/5">
                      <div>RECV: <strong className="text-white">1280x720 @ 30fps</strong></div>
                      <div>LATENCY: <strong className="text-white">28ms</strong></div>
                      <div>CODEC: <strong className="text-white">VP9 Secure</strong></div>
                      <div>SIGNAL: <strong className="text-green-400 font-black">EXCELLENT</strong></div>
                    </div>
                  </div>

                  {/* Drag-free PICTURE-IN-PICTURE Local camera view */}
                  <div className="absolute top-4 right-4 w-28 h-40 bg-slate-950 border-2 border-amber-400 rounded-2xl overflow-hidden shadow-xl">
                    {callState.cameraOn ? (
                      <video
                        ref={localVideoRef}
                        autoPlay
                        playsInline
                        muted
                        className="w-full h-full object-cover transform -scale-x-100"
                      />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center bg-slate-900 text-center p-2">
                        <VideoOff className="w-5 h-5 text-slate-500 mb-1" />
                        <span className="text-[8px] font-mono text-slate-400">Vijay (You)</span>
                      </div>
                    )}
                    <span className="absolute bottom-1 left-2 text-[8px] font-mono font-bold bg-black/60 px-1.5 py-0.5 rounded text-amber-400">
                      Self
                    </span>
                  </div>
                </div>
              ) : (
                
                // VOICE CALL SCREEN or RINGING/ENDED
                <div className="text-center space-y-5">
                  <div className="relative inline-block">
                    <div className={`w-32 h-32 rounded-full bg-gradient-to-br from-slate-800 to-slate-900 border border-white/10 flex items-center justify-center text-5xl shadow-2xl transition-all duration-700 ${
                      callState.status === 'ringing' || callState.status === 'incoming' ? 'scale-110 ring-4 ring-amber-500/30' : ''
                    }`}>
                      {CONTACTS.find(c => c.id === callState.contactId)?.avatar || '🌸'}
                    </div>

                    {(callState.status === 'ringing' || callState.status === 'incoming') && (
                      <div className="absolute inset-0 rounded-full border border-amber-400/30 animate-ping" />
                    )}
                  </div>

                  <div>
                    <h2 className="font-serif text-xl font-bold tracking-wide">
                      {CONTACTS.find(c => c.id === callState.contactId)?.name}
                    </h2>
                    <p className="font-sans text-[11px] text-amber-400 font-extrabold uppercase tracking-widest mt-1.5">
                      {CONTACTS.find(c => c.id === callState.contactId)?.relation}
                    </p>
                  </div>

                  {/* Dynamic calling status subtitle */}
                  <div className="font-mono text-xs text-slate-400">
                    {callState.status === 'ringing' && (
                      <span className="flex items-center justify-center gap-1.5">
                        <span className="w-2 h-2 bg-amber-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                        <span className="w-2 h-2 bg-amber-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                        <span className="w-2 h-2 bg-amber-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                        <span className="font-black text-amber-400 tracking-widest uppercase text-[10px]">DIALING OUTGOING SECURE...</span>
                      </span>
                    )}

                    {callState.status === 'incoming' && (
                      <span className="text-green-400 font-bold uppercase tracking-widest animate-pulse">
                        🔔 INCOMING SECURE CALL...
                      </span>
                    )}

                    {callState.status === 'connected' && (
                      <div className="space-y-3">
                        <p className="text-slate-200 font-bold tracking-widest text-[11px] uppercase">
                          CONNECTED VOICE STREAM
                        </p>
                        
                        {/* CSS-only Sound wave frequency visualizer */}
                        <div className="flex items-end justify-center gap-1.5 h-10 w-44 mx-auto pt-2 select-none">
                          <span className="w-1.5 bg-sky-400 rounded-full animate-pulse" style={{ height: '30%', animationDuration: '0.4s' }} />
                          <span className="w-1.5 bg-amber-400 rounded-full animate-pulse" style={{ height: '80%', animationDuration: '0.6s' }} />
                          <span className="w-1.5 bg-rose-400 rounded-full animate-pulse" style={{ height: '50%', animationDuration: '0.3s' }} />
                          <span className="w-1.5 bg-emerald-400 rounded-full animate-pulse" style={{ height: '90%', animationDuration: '0.5s' }} />
                          <span className="w-1.5 bg-sky-400 rounded-full animate-pulse" style={{ height: '40%', animationDuration: '0.4s' }} />
                          <span className="w-1.5 bg-amber-400 rounded-full animate-pulse" style={{ height: '70%', animationDuration: '0.7s' }} />
                        </div>
                      </div>
                    )}

                    {callState.status === 'ended' && (
                      <span className="text-red-400 font-bold tracking-widest uppercase">
                        🚫 CALL DISCONNECTED
                      </span>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Timer Counter */}
            {callState.status === 'connected' && (
              <div className="mb-6 flex items-center gap-2 bg-white/5 border border-white/10 rounded-full px-4 py-1.5 shadow-md">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span className="font-mono text-xs font-black tracking-widest text-slate-100">
                  {formatTimer(callState.duration)}
                </span>
              </div>
            )}

            {/* CALL ACTION DECK CONTROL PANEL */}
            <div className="w-full pt-6 border-t border-white/10 flex flex-col items-center gap-4">
              
              {callState.status === 'incoming' ? (
                /* INCOMING OPTION PANELS */
                <div className="flex gap-6 w-full max-w-sm">
                  <button
                    onClick={endCall}
                    className="flex-1 py-4.5 bg-red-600 hover:bg-red-700 active:scale-95 text-white font-sans text-xs font-black rounded-2xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg"
                  >
                    <PhoneOff className="w-4 h-4" />
                    <span>Decline</span>
                  </button>
                  <button
                    onClick={acceptCall}
                    className="flex-1 py-4.5 bg-green-500 hover:bg-green-600 active:scale-95 text-slate-950 font-sans text-xs font-black rounded-2xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg"
                  >
                    <Phone className="w-4 h-4" />
                    <span>Answer Call</span>
                  </button>
                </div>
              ) : (
                /* ACTIVE OR OUTGOING CONTROLS */
                <div className="flex items-center justify-center gap-5 w-full">
                  
                  {/* Mute Button */}
                  <button
                    onClick={() => setCallState(prev => prev ? { ...prev, muted: !prev.muted } : null)}
                    disabled={callState.status !== 'connected'}
                    className={`p-4 rounded-full border transition-all cursor-pointer ${
                      callState.muted 
                        ? 'bg-red-600/30 border-red-500 text-red-400 hover:bg-red-600/40' 
                        : 'bg-white/5 border-white/10 hover:bg-white/10 text-white'
                    } disabled:opacity-40`}
                    title="Mute Microphone"
                  >
                    {callState.muted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                  </button>

                  {/* Main End Call Trigger */}
                  <button
                    onClick={endCall}
                    className="p-5.5 bg-red-600 hover:bg-red-700 active:scale-90 text-white rounded-full transition-all cursor-pointer shadow-xl border border-red-500/30"
                    title="End secure call session"
                  >
                    <PhoneOff className="w-6 h-6" />
                  </button>

                  {/* Speaker Toggle (Voice Call) OR Camera On/Off Toggle (Video Call) */}
                  {callState.type === 'video' ? (
                    <button
                      onClick={() => setCallState(prev => prev ? { ...prev, cameraOn: !prev.cameraOn } : null)}
                      disabled={callState.status !== 'connected'}
                      className={`p-4 rounded-full border transition-all cursor-pointer ${
                        !callState.cameraOn 
                          ? 'bg-red-600/30 border-red-500 text-red-400 hover:bg-red-600/40' 
                          : 'bg-white/5 border-white/10 hover:bg-white/10 text-white'
                      } disabled:opacity-40`}
                      title="Toggle Camera Stream"
                    >
                      {callState.cameraOn ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
                    </button>
                  ) : (
                    <button
                      onClick={() => setCallState(prev => prev ? { ...prev, speaker: !prev.speaker } : null)}
                      disabled={callState.status !== 'connected'}
                      className={`p-4 rounded-full border transition-all cursor-pointer ${
                        !callState.speaker 
                          ? 'bg-slate-800 border-slate-700 text-slate-500' 
                          : 'bg-white/10 border-white/20 text-amber-400'
                      } disabled:opacity-40`}
                      title="Toggle Speaker Mode"
                    >
                      {callState.speaker ? <SpeakerIcon className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
                    </button>
                  )}
                </div>
              )}

              {/* Call telemetry helper subtitle */}
              <p className="text-[9px] font-mono text-slate-500 uppercase tracking-widest mt-1">
                {callState.status === 'connected' ? 'Connected via Secure Family Gateway' : 'Awaiting Connection...'}
              </p>

            </div>

          </div>
        </div>
      )}

    </div>
  );
}
