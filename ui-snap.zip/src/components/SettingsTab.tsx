import { useState, useEffect } from 'react';
import { Settings, ShieldAlert, Sparkles, RefreshCw, BarChart2, Save, Info } from 'lucide-react';

interface SettingsTabProps {
}

export default function SettingsTab({}: SettingsTabProps) {
  const [familyName, setFamilyName] = useState(() => {
    return localStorage.getItem('family_settings_name') || 'Nimmagadda';
  });

  const [toast, setToast] = useState<string | null>(null);

  // Stats calculation
  const [stats, setStats] = useState({
    totalCount: 0,
    aliveCount: 0,
    deceasedCount: 0,
    linkedCount: 0
  });

  const calculateStats = () => {
    const listSaved = localStorage.getItem('family_members_list');
    if (listSaved) {
      try {
        const parsed = JSON.parse(listSaved);
        if (Array.isArray(parsed)) {
          const total = parsed.length;
          const alive = parsed.filter((m: any) => m.isAlive).length;
          const deceased = total - alive;
          const linked = parsed.filter((m: any) => m.spouseId || m.fatherId || m.motherId).length;
          setStats({ totalCount: total, aliveCount: alive, deceasedCount: deceased, linkedCount: linked });
        }
      } catch (e) {
        console.error(e);
      }
    }
  };

  useEffect(() => {
    calculateStats();
  }, []);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    if (!familyName.trim()) return;
    localStorage.setItem('family_settings_name', familyName.trim());
    setToast('Settings saved successfully!');
    setTimeout(() => setToast(null), 3000);
    // Reload page to propagate changes to sidebar/header easily
    window.location.reload();
  };

  const handleResetApp = () => {
    if (confirm('WARNING: This will delete ALL custom-added family tree nodes, chat messages, calendar events, uploaded gallery memories, and revert the workspace to default sample values. Do you wish to continue?')) {
      localStorage.clear();
      setToast('Hub registry database reset to default values.');
      setTimeout(() => {
        setToast(null);
        window.location.reload();
      }, 1000);
    }
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Toast */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 border border-slate-800 text-white px-5 py-3 rounded-2xl flex items-center gap-2.5 shadow-2xl animate-fade-in font-sans text-xs font-semibold">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>{toast}</span>
        </div>
      )}

      {/* Banner */}
      <div className="bg-white border border-outline-variant/30 rounded-3xl p-6 sm:p-8 shadow-sm flex items-center gap-4">
        <span className="p-2.5 bg-amber-50 rounded-xl text-amber-600 border border-amber-200/50">
          <Settings className="w-5 h-5" />
        </span>
        <div className="space-y-1">
          <span className="font-sans text-[10px] font-black uppercase tracking-widest text-amber-600 bg-amber-50 px-2.5 py-1 rounded-md">Administration</span>
          <h2 className="font-serif text-2xl font-black text-gray-900 tracking-tight">Hub Registry & Settings</h2>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Settings Form */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white border border-outline-variant/30 rounded-3xl p-6 shadow-xs space-y-6">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
              <Settings className="w-4 h-4 text-slate-500" />
              <h3 className="font-serif text-sm font-bold text-gray-900">Custom Workspace Styling</h3>
            </div>

            <form onSubmit={handleSaveSettings} className="space-y-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Family Surname Hub Name</label>
                <input
                  type="text"
                  required
                  value={familyName}
                  onChange={(e) => setFamilyName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-4 py-2.5 text-xs font-medium outline-none"
                  placeholder="e.g. Nimmagadda"
                />
                <p className="text-[10px] text-slate-400">Updates headers, sidebars, and document descriptions dynamically across the app.</p>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end">
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-sans text-xs font-bold rounded-xl cursor-pointer transition-all flex items-center gap-1.5 shadow-md transform hover:-translate-y-0.5"
                >
                  <Save className="w-3.5 h-3.5 text-amber-400" />
                  <span>Save Changes</span>
                </button>
              </div>
            </form>
          </div>

          {/* Destructive zone */}
          <div className="bg-rose-50/50 border border-rose-200 rounded-3xl p-6 shadow-xs space-y-4">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-rose-600" />
              <h3 className="font-serif text-sm font-bold text-rose-900">Danger / Clear Zone</h3>
            </div>
            <p className="font-sans text-xs text-rose-800 leading-normal">
              Perform structural garbage collection. Clear all stored announcements, chat history, family tree node changes, and reset to defaults.
            </p>

            <button
              onClick={handleResetApp}
              className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-sans text-xs font-bold rounded-xl cursor-pointer transition-all flex items-center gap-1.5 shadow-md"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Full Factory Database Reset</span>
            </button>
          </div>
        </div>

        {/* Info & Registry Stats */}
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 text-white rounded-3xl p-6 shadow-xl space-y-6">
            
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
              <BarChart2 className="w-4 h-4 text-amber-400" />
              <h3 className="font-serif text-sm font-bold text-slate-200">Registry Statistics</h3>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-slate-800/50 rounded-2xl border border-slate-800">
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Members</p>
                <p className="text-2xl font-serif font-black text-amber-400 mt-1">{stats.totalCount}</p>
              </div>
              <div className="p-4 bg-slate-800/50 rounded-2xl border border-slate-800">
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Alive Nodes</p>
                <p className="text-2xl font-serif font-black text-emerald-400 mt-1">{stats.aliveCount}</p>
              </div>
              <div className="p-4 bg-slate-800/50 rounded-2xl border border-slate-800">
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Remembrances</p>
                <p className="text-2xl font-serif font-black text-slate-400 mt-1">{stats.deceasedCount}</p>
              </div>
              <div className="p-4 bg-slate-800/50 rounded-2xl border border-slate-800">
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Linked Trees</p>
                <p className="text-2xl font-serif font-black text-amber-500 mt-1">{stats.linkedCount}</p>
              </div>
            </div>

            <div className="p-4 bg-slate-800/30 rounded-2xl border border-slate-800 flex gap-2.5">
              <Info className="w-4 h-4 text-slate-400 shrink-0" />
              <div className="text-[11px] text-slate-300 leading-normal font-medium">
                Linkages include marriage partnerships and maternal/paternal connections. A fully bound registry represents a highly interconnected family branch.
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
