import { useState, useEffect } from 'react';
import { Image as ImageIcon, PlusCircle, Check, Heart, AlertCircle, Trash2 } from 'lucide-react';
import { GalleryItem } from '../types';
import { INITIAL_GALLERY } from '../data';

interface GalleryTabProps {
  searchQuery: string;
}

export default function GalleryTab({ searchQuery }: GalleryTabProps) {
  const [gallery, setGallery] = useState<GalleryItem[]>(() => {
    const saved = localStorage.getItem('family_gallery');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return INITIAL_GALLERY;
  });

  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [isAddOpen, setIsAddOpen] = useState(false);

  // Form State
  const [formTitle, setFormTitle] = useState('');
  const [formUrl, setFormUrl] = useState('');
  const [formCategory, setFormCategory] = useState<GalleryItem['category']>('candid');
  const [formUploader, setFormUploader] = useState('Vijay Nimmagadda');

  useEffect(() => {
    localStorage.setItem('family_gallery', JSON.stringify(gallery));
  }, [gallery]);

  const handleLike = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setGallery(prev => prev.map(item => {
      if (item.id === id) return { ...item, likes: item.likes + 1 };
      return item;
    }));
  };

  const handleDeletePhoto = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Are you sure you want to remove this family memory from the gallery?')) {
      setGallery(prev => prev.filter(item => item.id !== id));
    }
  };

  const handleAddPhoto = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) return;

    const defaultUrl = 'https://images.unsplash.com/photo-1543269865-cbf427effbad?q=80&w=1200'; // high quality placeholder
    const finalUrl = formUrl.trim() || defaultUrl;

    const newPhoto: GalleryItem = {
      id: 'gal-' + Date.now(),
      title: formTitle.trim(),
      url: finalUrl,
      category: formCategory,
      uploader: formUploader.trim() || 'Vijay Nimmagadda',
      date: new Date().toISOString().split('T')[0],
      likes: 0
    };

    setGallery(prev => [newPhoto, ...prev]);
    setIsAddOpen(false);

    // Reset Form
    setFormTitle('');
    setFormUrl('');
    setFormCategory('candid');
  };

  const filteredGallery = gallery.filter(item => {
    const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.uploader.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-8 pb-16">
      {/* Banner */}
      <div className="bg-white border border-outline-variant/30 rounded-3xl p-6 sm:p-8 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="space-y-1.5 max-w-xl">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-amber-50 rounded-xl text-amber-600 border border-amber-200/50">
              <ImageIcon className="w-5 h-5" />
            </span>
            <span className="font-sans text-[10px] font-black uppercase tracking-widest text-amber-600 bg-amber-50 px-2.5 py-1 rounded-md">Family Album</span>
          </div>
          <h2 className="font-serif text-2xl font-black text-gray-900 tracking-tight">Shared Family Memories</h2>
          <p className="font-sans text-xs text-on-surface-variant leading-relaxed">
            A collaborative photo repository. Upload historical ancestors portraits, reunion snapshots, or daily family candids fully stored locally.
          </p>
        </div>
        <button
          onClick={() => setIsAddOpen(true)}
          className="w-full md:w-auto px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-sans text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 shadow-md transition-all cursor-pointer shrink-0"
        >
          <PlusCircle className="w-4 h-4 text-amber-400" />
          <span>Upload Memory</span>
        </button>
      </div>

      {/* Categories Filter list */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200/60 pb-4">
        {['all', 'historical', 'reunions', 'candid', 'nature'].map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-4 py-1.5 rounded-full font-sans text-xs font-bold capitalize transition-all cursor-pointer border ${
              activeCategory === cat
                ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'
            }`}
          >
            {cat === 'all' ? 'All Memories' : cat}
          </button>
        ))}
      </div>

      {/* Grid Layout */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredGallery.map((photo) => (
          <div key={photo.id} className="group bg-white border border-outline-variant/30 rounded-3xl overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between">
            {/* Image Box */}
            <div className="relative h-56 bg-slate-100 overflow-hidden">
              <img
                src={photo.url}
                alt={photo.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-all duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-60 group-hover:opacity-85 transition-opacity" />
              
              {/* Category Tag */}
              <span className="absolute top-3.5 left-3.5 bg-slate-950/85 text-[8px] text-white font-black uppercase tracking-widest px-2.5 py-1 rounded">
                {photo.category}
              </span>

              {/* Delete Button (hover overlay) */}
              <button
                onClick={(e) => handleDeletePhoto(photo.id, e)}
                className="absolute top-3.5 right-3.5 p-1.5 bg-slate-950/85 text-slate-400 hover:text-red-500 rounded-full cursor-pointer transition-colors"
                title="Delete photo memory"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>

              {/* Title Overlay */}
              <div className="absolute bottom-3.5 left-3.5 right-3.5">
                <h4 className="font-serif text-white font-bold text-sm tracking-tight drop-shadow-sm truncate">{photo.title}</h4>
              </div>
            </div>

            {/* Bottom Panel */}
            <div className="p-4 flex items-center justify-between gap-4 border-t border-slate-50">
              <div className="min-w-0">
                <p className="font-sans text-[10px] text-slate-400 font-bold">Uploader: <span className="text-slate-600 font-semibold">{photo.uploader}</span></p>
                <p className="font-mono text-[9px] text-slate-400 mt-0.5">{photo.date}</p>
              </div>

              <button
                onClick={(e) => handleLike(photo.id, e)}
                className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-100/50 rounded-xl flex items-center gap-1.5 font-sans text-[10px] font-black uppercase transition-all cursor-pointer hover:scale-105"
              >
                <Heart className="w-3.5 h-3.5 fill-rose-600" />
                <span>{photo.likes}</span>
              </button>
            </div>
          </div>
        ))}

        {filteredGallery.length === 0 && (
          <div className="col-span-full text-center py-20 bg-white border border-dashed border-slate-200 rounded-3xl p-6 text-slate-400">
            <AlertCircle className="w-8 h-8 mx-auto text-slate-300 mb-2" />
            <span className="font-sans text-xs font-semibold">No family photo memories match your filter search.</span>
          </div>
        )}
      </div>

      {/* UPLOAD MEMORY MODAL */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden border border-slate-100 flex flex-col max-h-[90vh] animate-fade-in">
            
            <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <div className="flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-amber-500" />
                <h3 className="font-serif text-base font-bold text-gray-900">Upload Shared Memory</h3>
              </div>
              <button 
                onClick={() => setIsAddOpen(false)}
                className="p-1.5 rounded-full hover:bg-slate-200 text-slate-500 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddPhoto} className="p-6 space-y-4">
              
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Photo Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Traditional Reunion lunch 2024"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-4 py-2.5 text-xs font-medium outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Category</label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as GalleryItem['category'])}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-3 py-2.5 text-xs font-medium outline-none"
                  >
                    <option value="historical">Historical Archive</option>
                    <option value="reunions">Family Reunion</option>
                    <option value="candid">Candid Snapshots</option>
                    <option value="nature">Nature / Homestead</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Uploader Name</label>
                  <input
                    type="text"
                    placeholder="Your Name"
                    value={formUploader}
                    onChange={(e) => setFormUploader(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-4 py-2.5 text-xs font-medium outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Photo Web URL (Optional)</label>
                <input
                  type="url"
                  placeholder="Leave blank for a high-quality standard placeholder"
                  value={formUrl}
                  onChange={(e) => setFormUrl(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-4 py-2.5 text-xs font-medium outline-none"
                />
                <p className="text-[10px] text-slate-400">Provide any web image URL (Unsplash, etc.) to view custom images instantly.</p>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-sans text-xs font-bold rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-sans text-xs font-bold rounded-xl cursor-pointer flex items-center gap-1"
                >
                  <Check className="w-3.5 h-3.5 text-amber-400" />
                  <span>Upload Memory</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}

// Minimal placeholder Close icon
function X(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <line x1="18" y1="6" x2="6" y2="18"></line>
      <line x1="6" y1="6" x2="18" y2="18"></line>
    </svg>
  );
}
