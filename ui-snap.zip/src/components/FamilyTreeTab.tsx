import { useState, useEffect, useRef } from 'react';
import { 
  Network, 
  GitFork, 
  Heart, 
  PlusCircle, 
  Trash2, 
  Link2, 
  Users, 
  Check, 
  MapPin, 
  Calendar, 
  Sparkles, 
  RefreshCw, 
  UserMinus,
  X,
  Flame
} from 'lucide-react';
import { FamilyMember } from '../types';

interface FamilyTreeTabProps {
  searchQuery: string;
}

const GENERATION_PRESETS = [
  { id: 'gen-great-grand', title: '1st Generation (Great-Grandparents)', relations: ['Great Grandfather', 'Great Grandmother'] },
  { id: 'gen-grand', title: '2nd Generation (Grandparents)', relations: ['Grandfather', 'Grandmother'] },
  { id: 'gen-parents', title: '3rd Generation (Parents, Uncles & Aunts)', relations: ['Father', 'Mother', 'Uncle', 'Aunt'] },
  { id: 'gen-self', title: '4th Generation (Self & Siblings)', relations: ['Self', 'Spouse', 'Brother', 'Sister', 'Cousin'] },
  { id: 'gen-children', title: '5th Generation (Next Generation)', relations: ['Son', 'Daughter'] },
  { id: 'gen-other', title: 'Extended Family', relations: ['Other'] }
];

const RELATION_OPTIONS = [
  'Self', 'Spouse', 'Father', 'Mother', 'Brother', 'Sister', 'Son', 'Daughter', 
  'Uncle', 'Aunt', 'Cousin', 'Grandfather', 'Grandmother', 'Great Grandfather', 'Great Grandmother', 'Other'
];

export default function FamilyTreeTab({ searchQuery }: FamilyTreeTabProps) {
  // Load members from localStorage (sharing state with SettingsTab)
  const [members, setMembers] = useState<FamilyMember[]>(() => {
    const saved = localStorage.getItem('family_members_list');
    if (saved) {
      try {
        return JSON.parse(saved) as FamilyMember[];
      } catch (e) {
        console.error('Failed to parse family members list in Tree Tab', e);
      }
    }
    return [];
  });

  const [selectedMemberId, setSelectedMemberId] = useState<string | null>(() => {
    const saved = localStorage.getItem('family_members_list');
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as FamilyMember[];
        if (parsed && parsed.length > 0) return parsed[0].id;
      } catch (e) {
        console.error(e);
      }
    }
    return null;
  });
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [memoriesModalMember, setMemoriesModalMember] = useState<FamilyMember | null>(null);
  const [linkTarget, setLinkTarget] = useState<{ memberId: string; type: 'spouse' | 'father' | 'mother' } | null>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' } | null>(null);

  // Board layout & drag states
  const [viewMode, setViewMode] = useState<'board' | 'directory'>('board');
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [dropLinkTarget, setDropLinkTarget] = useState<{ sourceId: string; targetId: string } | null>(null);
  const canvasRef = useRef<HTMLDivElement>(null);

  // Saved positioning dictionary
  const [positions, setPositions] = useState<Record<string, { x: number; y: number }>>(() => {
    const saved = localStorage.getItem('family_tree_positions');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse family tree positions', e);
      }
    }
    return {};
  });

  // Save positions to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('family_tree_positions', JSON.stringify(positions));
  }, [positions]);

  // Add Member Form State
  const [formName, setFormName] = useState('');
  const [formRelation, setFormRelation] = useState<FamilyMember['relation']>('Self');
  const [formBirthYear, setFormBirthYear] = useState('');
  const [formIsAlive, setFormIsAlive] = useState(true);
  const [formDeathYear, setFormDeathYear] = useState('');
  const [formBio, setFormBio] = useState('');
  const [formLocation, setFormLocation] = useState('');
  const [formFatherId, setFormFatherId] = useState('');
  const [formMotherId, setFormMotherId] = useState('');
  const [formSpouseId, setFormSpouseId] = useState('');

  // Enhanced Quick-creation & double-click position states
  const [doubleClickedPos, setDoubleClickedPos] = useState<{ x: number; y: number } | null>(null);
  const [linkMode, setLinkMode] = useState<'existing' | 'create'>('existing');
  const [quickName, setQuickName] = useState('');
  const [quickBirthYear, setQuickBirthYear] = useState('');
  const [quickIsAlive, setQuickIsAlive] = useState(true);
  const [quickDeathYear, setQuickDeathYear] = useState('');
  const [quickLocation, setQuickLocation] = useState('');

  // Inline forms in Lineage Inspector
  const [showInlineChildForm, setShowInlineChildForm] = useState(false);
  const [inlineChildName, setInlineChildName] = useState('');
  const [inlineChildRelation, setInlineChildRelation] = useState<'Son' | 'Daughter'>('Son');
  const [inlineChildBirthYear, setInlineChildBirthYear] = useState('');

  const [showInlineSiblingForm, setShowInlineSiblingForm] = useState(false);
  const [inlineSiblingName, setInlineSiblingName] = useState('');
  const [inlineSiblingRelation, setInlineSiblingRelation] = useState<'Brother' | 'Sister'>('Brother');
  const [inlineSiblingBirthYear, setInlineSiblingBirthYear] = useState('');

  // Save changes to localStorage whenever members change
  useEffect(() => {
    localStorage.setItem('family_members_list', JSON.stringify(members));
  }, [members]);

  const showToast = (message: string, type: 'success' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .filter(Boolean)
      .map(n => n[0])
      .slice(0, 2)
      .join('')
      .toUpperCase() || '?';
  };

  const getMemberById = (id: string | undefined) => {
    if (!id) return null;
    return members.find(m => m.id === id) || null;
  };

  // Pre-calculate positions of all members (using saved coordinates or auto-layout)
  const getInitialPosition = (id: string, allMembers: FamilyMember[]) => {
    const member = allMembers.find(m => m.id === id);
    if (!member) return { x: 100, y: 100 };
    
    // Resolve dynamic relation for Spouse
    let activeRelation = member.relation;
    if (member.relation === 'Spouse' && member.spouseId) {
      const partner = allMembers.find(m => m.id === member.spouseId);
      if (partner && partner.relation !== 'Spouse') {
        activeRelation = partner.relation;
      }
    }

    // Find generation preset index
    const genIndex = GENERATION_PRESETS.findIndex(gen => gen.relations.includes(activeRelation));
    const activeGenIndex = genIndex !== -1 ? genIndex : 5;
    
    // Find all members who belong to this generation
    const getMemberGenIndex = (m: FamilyMember): number => {
      let rel = m.relation;
      if (rel === 'Spouse' && m.spouseId) {
        const partner = allMembers.find(p => p.id === m.spouseId);
        if (partner && partner.relation !== 'Spouse') rel = partner.relation;
      }
      const gi = GENERATION_PRESETS.findIndex(gen => gen.relations.includes(rel));
      return gi !== -1 ? gi : 5;
    };

    const genMembers = allMembers.filter(m => getMemberGenIndex(m) === activeGenIndex);
    
    // Group married couples together to keep them side-by-side
    const couples: Record<string, FamilyMember[]> = {};
    const singleMembers: FamilyMember[] = [];
    const visited = new Set<string>();

    genMembers.forEach(m => {
      if (visited.has(m.id)) return;
      if (m.spouseId) {
        const partner = genMembers.find(p => p.id === m.spouseId);
        if (partner) {
          const coupleKey = [m.id, partner.id].sort().join('-');
          couples[coupleKey] = [m, partner];
          visited.add(m.id);
          visited.add(partner.id);
          return;
        }
      }
      singleMembers.push(m);
      visited.add(m.id);
    });

    interface FamilyGroup {
      members: FamilyMember[];
      minBirthYear: number;
    }

    const groups: FamilyGroup[] = [];

    // Add couples as groups
    Object.values(couples).forEach(pair => {
      const minBY = Math.min(...pair.map(m => m.birthYear || 9999));
      // Sort within the couple: put 'Self', 'Father', 'Mother', or male relations first
      pair.sort((a, b) => {
        const priority = (rel: string) => {
          if (['Self', 'Father', 'Grandfather', 'Great Grandfather'].includes(rel)) return 1;
          if (['Mother', 'Grandmother', 'Great Grandmother'].includes(rel)) return 2;
          return 3;
        };
        return priority(a.relation) - priority(b.relation) || a.name.localeCompare(b.name);
      });
      groups.push({ members: pair, minBirthYear: minBY });
    });

    // Add singles as groups
    singleMembers.forEach(m => {
      groups.push({ members: [m], minBirthYear: m.birthYear || 9999 });
    });

    // Sort groups by minimum birth year
    groups.sort((a, b) => a.minBirthYear - b.minBirthYear);

    // Flatten back into list
    const sortedGenMembers: FamilyMember[] = [];
    groups.forEach(g => {
      sortedGenMembers.push(...g.members);
    });

    const memberIndexInGen = sortedGenMembers.findIndex(m => m.id === id);
    const y = 50 + activeGenIndex * 155; // 155px vertical spacing
    const totalInGen = sortedGenMembers.length;
    
    // Width of canvas is 1200px, let's space within 1000px
    const step = 1000 / (totalInGen + 1);
    const x = step * (memberIndexInGen + 1) + 100;
    
    return { x: Math.round(x), y: Math.round(y) };
  };

  // Build a complete resolved positions dictionary
  const resolvedPositions = members.reduce((acc, m) => {
    acc[m.id] = positions[m.id] || getInitialPosition(m.id, members);
    return acc;
  }, {} as Record<string, { x: number; y: number }>);

  // Mouse drag handles
  const handleMouseDown = (e: React.MouseEvent, id: string) => {
    if ((e.target as HTMLElement).closest('button') || (e.target as HTMLElement).closest('select')) return;
    e.preventDefault();
    setDraggingId(id);
    setSelectedMemberId(id);
    
    const currentPos = resolvedPositions[id];
    setDragStart({
      x: e.clientX - currentPos.x,
      y: e.clientY - currentPos.y
    });
  };

  const handleTouchStart = (e: React.TouchEvent, id: string) => {
    if ((e.target as HTMLElement).closest('button') || (e.target as HTMLElement).closest('select')) return;
    const touch = e.touches[0];
    setDraggingId(id);
    setSelectedMemberId(id);
    
    const currentPos = resolvedPositions[id];
    setDragStart({
      x: touch.clientX - currentPos.x,
      y: touch.clientY - currentPos.y
    });
  };

  // Drag event listeners effect
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!draggingId) return;
      const rect = canvasRef.current?.getBoundingClientRect();
      if (!rect) return;
      
      let x = e.clientX - dragStart.x;
      let y = e.clientY - dragStart.y;
      
      // Constrain inside canvas dimensions (1200px wide, 920px tall)
      // Card size: width 190px, height 90px
      x = Math.max(10, Math.min(x, 1200 - 200));
      y = Math.max(10, Math.min(y, 920 - 100));
      
      setPositions(prev => ({
        ...prev,
        [draggingId]: { x, y }
      }));
    };

    const handleMouseUp = () => {
      if (!draggingId) return;
      
      // Check overlap
      const dragPos = positions[draggingId] || resolvedPositions[draggingId];
      if (dragPos) {
        const dragCenter = { x: dragPos.x + 95, y: dragPos.y + 45 };
        
        const targetMember = members.find(m => {
          if (m.id === draggingId) return false;
          const targetPos = resolvedPositions[m.id];
          if (!targetPos) return false;
          return (
            dragCenter.x >= targetPos.x &&
            dragCenter.x <= targetPos.x + 190 &&
            dragCenter.y >= targetPos.y &&
            dragCenter.y <= targetPos.y + 90
          );
        });
        
        if (targetMember) {
          setDropLinkTarget({ sourceId: draggingId, targetId: targetMember.id });
        }
      }
      
      setDraggingId(null);
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (!draggingId) return;
      const touch = e.touches[0];
      
      let x = touch.clientX - dragStart.x;
      let y = touch.clientY - dragStart.y;
      
      x = Math.max(10, Math.min(x, 1200 - 200));
      y = Math.max(10, Math.min(y, 920 - 100));
      
      setPositions(prev => ({
        ...prev,
        [draggingId]: { x, y }
      }));
    };

    if (draggingId) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      window.addEventListener('touchmove', handleTouchMove, { passive: true });
      window.addEventListener('touchend', handleMouseUp);
    }
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleMouseUp);
    };
  }, [draggingId, dragStart, positions, resolvedPositions, members]);

  // Reset positions to defaults
  const handleAutoArrange = () => {
    if (confirm('Are you sure you want to reset all card positions to their default generational auto-layout?')) {
      setPositions({});
      showToast('Board layout auto-arranged successfully!');
    }
  };

  // Handle adding a family member
  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) {
      showToast('Please enter a name', 'info');
      return;
    }

    const newId = 'mem-' + Date.now();
    const newMember: FamilyMember = {
      id: newId,
      name: formName.trim(),
      relation: formRelation,
      avatar: '',
      birthYear: formBirthYear ? parseInt(formBirthYear, 10) : undefined,
      isAlive: formIsAlive,
      deathYear: !formIsAlive && formDeathYear ? parseInt(formDeathYear, 10) : undefined,
      bio: formBio.trim() || undefined,
      location: formLocation.trim() || undefined,
      fatherId: formFatherId || undefined,
      motherId: formMotherId || undefined,
      spouseId: formSpouseId || undefined
    };

    // If spouse linkage is established, bind mutual spouse relationship
    let updatedMembers = [...members, newMember];
    if (formSpouseId) {
      updatedMembers = updatedMembers.map(m => {
        if (m.id === formSpouseId) {
          return { ...m, spouseId: newId };
        }
        return m;
      });
    }

    setMembers(updatedMembers);
    setSelectedMemberId(newId);
    setIsAddOpen(false);

    // Set custom coordinates if double clicked on canvas background
    if (doubleClickedPos) {
      setPositions(prev => ({
        ...prev,
        [newId]: doubleClickedPos
      }));
      setDoubleClickedPos(null);
    }

    showToast(`Added ${newMember.name} to the family tree!`);

    // Reset Form
    setFormName('');
    setFormRelation('Self');
    setFormBirthYear('');
    setFormIsAlive(true);
    setFormDeathYear('');
    setFormBio('');
    setFormLocation('');
    setFormFatherId('');
    setFormMotherId('');
    setFormSpouseId('');
  };

  // Handle quick creating a family member and linking them instantly
  const handleQuickCreateAndLink = () => {
    if (!linkTarget) return;
    if (!quickName.trim()) {
      showToast('Please enter a name for the new relative', 'info');
      return;
    }

    const { memberId, type } = linkTarget;
    const newId = 'mem-' + Date.now();
    
    // Guess a logical relation based on type and active member
    let predictedRelation: FamilyMember['relation'] = 'Other';
    if (type === 'father') predictedRelation = 'Father';
    if (type === 'mother') predictedRelation = 'Mother';
    if (type === 'spouse') predictedRelation = 'Spouse';

    const newMember: FamilyMember = {
      id: newId,
      name: quickName.trim(),
      relation: predictedRelation,
      avatar: '',
      birthYear: quickBirthYear ? parseInt(quickBirthYear, 10) : undefined,
      isAlive: quickIsAlive,
      deathYear: !quickIsAlive && quickDeathYear ? parseInt(quickDeathYear, 10) : undefined,
      location: quickLocation.trim() || undefined
    };

    // Auto-calculate position near the linked parent/spouse
    const activeMemberPos = resolvedPositions[memberId];
    if (activeMemberPos) {
      let offsetPos = { x: activeMemberPos.x, y: activeMemberPos.y };
      if (type === 'father') {
        offsetPos = { x: Math.max(10, activeMemberPos.x - 110), y: Math.max(10, activeMemberPos.y - 120) };
      } else if (type === 'mother') {
        offsetPos = { x: Math.min(1200 - 200, activeMemberPos.x + 110), y: Math.max(10, activeMemberPos.y - 120) };
      } else if (type === 'spouse') {
        offsetPos = { x: Math.min(1200 - 200, activeMemberPos.x + 210), y: activeMemberPos.y };
      }
      setPositions(prev => ({
        ...prev,
        [newId]: offsetPos
      }));
    }

    // Link retroactively to current members list
    setMembers(prev => {
      return [...prev, newMember].map(m => {
        if (m.id === memberId) {
          if (type === 'spouse') return { ...m, spouseId: newId };
          if (type === 'father') return { ...m, fatherId: newId };
          if (type === 'mother') return { ...m, motherId: newId };
        }
        // If establishing mutual spouse
        if (type === 'spouse' && m.id === newId) {
          return { ...m, spouseId: memberId };
        }
        return m;
      });
    });

    showToast(`Quick-created and linked ${newMember.name}!`);
    
    // Close & reset
    setLinkTarget(null);
    setLinkMode('existing');
    setQuickName('');
    setQuickBirthYear('');
    setQuickIsAlive(true);
    setQuickDeathYear('');
    setQuickLocation('');
  };

  // Create an inline child under active parent
  const handleCreateInlineChild = () => {
    if (!selectedMember) return;
    if (!inlineChildName.trim()) {
      showToast('Please enter a name', 'info');
      return;
    }

    const newId = 'mem-' + Date.now();
    const newMember: FamilyMember = {
      id: newId,
      name: inlineChildName.trim(),
      relation: inlineChildRelation,
      avatar: '',
      birthYear: inlineChildBirthYear ? parseInt(inlineChildBirthYear, 10) : undefined,
      isAlive: true,
    };

    // Determine maternal or paternal linkage
    const femaleRelations = ['Mother', 'Sister', 'Daughter', 'Grandmother', 'Great Grandmother', 'Aunt'];
    const isFemaleParent = femaleRelations.includes(selectedMember.relation);
    
    if (isFemaleParent) {
      newMember.motherId = selectedMember.id;
      if (selectedMember.spouseId) {
        newMember.fatherId = selectedMember.spouseId;
      }
    } else {
      newMember.fatherId = selectedMember.id;
      if (selectedMember.spouseId) {
        newMember.motherId = selectedMember.spouseId;
      }
    }

    // Auto-place below parents on canvas
    const parentPos = resolvedPositions[selectedMember.id];
    if (parentPos) {
      setPositions(prev => ({
        ...prev,
        [newId]: { x: parentPos.x, y: Math.min(920 - 100, parentPos.y + 150) }
      }));
    }

    setMembers(prev => [...prev, newMember]);
    setSelectedMemberId(newId);
    showToast(`Successfully added child: ${newMember.name}`);
    
    // reset form
    setInlineChildName('');
    setInlineChildBirthYear('');
    setShowInlineChildForm(false);
  };

  // Create an inline sibling sharing same parents
  const handleCreateInlineSibling = () => {
    if (!selectedMember) return;
    if (!inlineSiblingName.trim()) {
      showToast('Please enter a name', 'info');
      return;
    }

    const newId = 'mem-' + Date.now();
    const newMember: FamilyMember = {
      id: newId,
      name: inlineSiblingName.trim(),
      relation: inlineSiblingRelation,
      avatar: '',
      birthYear: inlineSiblingBirthYear ? parseInt(inlineSiblingBirthYear, 10) : undefined,
      isAlive: true,
      fatherId: selectedMember.fatherId,
      motherId: selectedMember.motherId
    };

    // Auto-place sibling to the right on canvas
    const activeMemberPos = resolvedPositions[selectedMember.id];
    if (activeMemberPos) {
      setPositions(prev => ({
        ...prev,
        [newId]: { x: Math.min(1200 - 200, activeMemberPos.x + 210), y: activeMemberPos.y }
      }));
    }

    setMembers(prev => [...prev, newMember]);
    setSelectedMemberId(newId);
    showToast(`Successfully added sibling: ${newMember.name}`);
    
    // reset form
    setInlineSiblingName('');
    setInlineSiblingBirthYear('');
    setShowInlineSiblingForm(false);
  };

  // Connect relationships retroactively
  const handleEstablishRelation = (targetId: string) => {
    if (!linkTarget) return;

    const { memberId, type } = linkTarget;

    setMembers(prev => {
      return prev.map(m => {
        if (m.id === memberId) {
          if (type === 'spouse') return { ...m, spouseId: targetId };
          if (type === 'father') return { ...m, fatherId: targetId };
          if (type === 'mother') return { ...m, motherId: targetId };
        }
        // If establishing mutual spouse
        if (type === 'spouse' && m.id === targetId) {
          return { ...m, spouseId: memberId };
        }
        return m;
      });
    });

    showToast(`Successfully linked relation!`);
    setLinkTarget(null);
  };

  const handleDropLinkRelation = (type: 'spouse' | 'father' | 'mother') => {
    if (!dropLinkTarget) return;
    const { sourceId, targetId } = dropLinkTarget;
    
    setMembers(prev => prev.map(m => {
      if (m.id === sourceId) {
        if (type === 'spouse') return { ...m, spouseId: targetId };
        if (type === 'father') return { ...m, fatherId: targetId };
        if (type === 'mother') return { ...m, motherId: targetId };
      }
      if (m.id === targetId && type === 'spouse') {
        return { ...m, spouseId: sourceId };
      }
      return m;
    }));
    
    const sourceName = members.find(m => m.id === sourceId)?.name;
    const targetName = members.find(m => m.id === targetId)?.name;
    showToast(`Linked: ${targetName} is now the ${type} of ${sourceName}!`);
    setDropLinkTarget(null);
  };

  // Remove relationships
  const handleRemoveRelation = (memberId: string, type: 'spouse' | 'father' | 'mother') => {
    setMembers(prev => {
      return prev.map(m => {
        if (m.id === memberId) {
          if (type === 'spouse') {
            return { ...m, spouseId: undefined };
          }
          if (type === 'father') return { ...m, fatherId: undefined };
          if (type === 'mother') return { ...m, motherId: undefined };
        }
        if (type === 'spouse' && m.spouseId === memberId) {
          return { ...m, spouseId: undefined };
        }
        return m;
      });
    });
    showToast('Relation disconnected');
  };

  // Delete Member completely
  const handleDeleteMember = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Are you sure you want to delete this family member from the entire registry? This will clean up their linkages.')) {
      setMembers(prev => {
        return prev
          .filter(m => m.id !== id)
          .map(m => {
            const updated = { ...m };
            if (updated.spouseId === id) updated.spouseId = undefined;
            if (updated.fatherId === id) updated.fatherId = undefined;
            if (updated.motherId === id) updated.motherId = undefined;
            return updated;
          });
      });
      if (selectedMemberId === id) {
        setSelectedMemberId(null);
      }
      showToast('Family member removed successfully');
    }
  };

  // Restore Default demo tree
  const handleRestoreDefaults = () => {
    if (confirm('Restore default family tree registry? This will overwrite current changes.')) {
      const defaults: FamilyMember[] = [
        { id: 'mem-1', name: 'Vijay Nimmagadda', relation: 'Self', avatar: '', birthYear: 1982, isAlive: true, email: 'vijay.nimmagadda@gmail.com', phone: '+91 98480 22338', location: 'Hyderabad, India', bio: 'Keeper of the family archives.', motherId: 'mem-2' },
        { id: 'mem-2', name: 'Amma (Sita Nimmagadda)', relation: 'Mother', avatar: '', birthYear: 1958, isAlive: true, email: 'sita.nimmagadda@family.com', location: 'Visakhapatnam, India', bio: 'Avid organic gardener.' },
        { id: 'mem-3', name: 'Suresh Nimmagadda', relation: 'Uncle', avatar: '', birthYear: 1961, isAlive: true, phone: '+91 99890 44552', location: 'Bangalore, India', bio: 'Senior chess mentor.' },
        { id: 'mem-4', name: 'Priya Nimmagadda', relation: 'Sister', avatar: '', birthYear: 1985, isAlive: true, email: 'priya.nimmagadda@gmail.com', location: 'San Jose, CA', bio: 'Software architect.', motherId: 'mem-2' },
        { id: 'mem-5', name: 'Vikram Nimmagadda', relation: 'Brother', avatar: '', birthYear: 1990, isAlive: true, location: 'London, UK', bio: 'History buff.', motherId: 'mem-2' }
      ];
      setMembers(defaults);
      setSelectedMemberId('mem-1');
      showToast('Sample family tree restored!');
    }
  };

  // Filtering for search query
  const filteredMembers = members.filter(m => 
    m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.relation.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (m.location && m.location.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const selectedMember = getMemberById(selectedMemberId || undefined);

  // Lineage Calculations for Selected Member
  const spouse = selectedMember?.spouseId ? getMemberById(selectedMember.spouseId) : null;
  const father = selectedMember?.fatherId ? getMemberById(selectedMember.fatherId) : null;
  const mother = selectedMember?.motherId ? getMemberById(selectedMember.motherId) : null;
  const children = selectedMember 
    ? members.filter(m => m.fatherId === selectedMember.id || m.motherId === selectedMember.id)
    : [];
  const siblings = selectedMember
    ? members.filter(m => 
        m.id !== selectedMember.id && 
        ((selectedMember.fatherId && m.fatherId === selectedMember.fatherId) || 
         (selectedMember.motherId && m.motherId === selectedMember.motherId))
      )
    : [];

  return (
    <div className="space-y-8 pb-16 animate-fade-in">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 border border-slate-800 text-white px-5 py-3 rounded-2xl flex items-center gap-2.5 shadow-2xl font-sans text-xs font-semibold">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>{toast.message}</span>
        </div>
      )}

      {/* Main Header Card */}
      <div className="bg-white border border-outline-variant/30 rounded-3xl p-6 sm:p-8 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="space-y-1.5 max-w-xl">
          <div className="flex items-center gap-2.5">
            <span className="p-2 bg-amber-50 rounded-xl text-amber-600 border border-amber-200/50">
              <Network className="w-5 h-5" />
            </span>
            <span className="font-sans text-[10px] font-black uppercase tracking-widest text-amber-600 bg-amber-50 px-2.5 py-1 rounded-md">Interactive Registry</span>
          </div>
          <h2 className="font-serif text-2xl font-black text-gray-900 tracking-tight">Generational Family Tree</h2>
          <p className="font-sans text-xs text-on-surface-variant leading-relaxed">
            Map relationships, build dynamic generational linkages, and connect spouse and parenting trees completely offline. Fallback initials keep pages clean while you upload custom photos.
          </p>
        </div>
        <div className="flex flex-wrap gap-2 shrink-0 w-full md:w-auto">
          <button
            onClick={() => setIsAddOpen(true)}
            className="flex-1 sm:flex-none px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-sans text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 shadow-md transition-all cursor-pointer transform hover:-translate-y-0.5"
          >
            <PlusCircle className="w-4 h-4 text-amber-400" />
            <span>Add Family Member</span>
          </button>
          <button
            onClick={handleRestoreDefaults}
            className="px-3.5 py-2.5 bg-slate-50 border border-slate-200 hover:bg-slate-100 text-slate-700 font-sans text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer"
            title="Restore default sample data"
          >
            <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
            <span className="hidden sm:inline">Reset Tree</span>
          </button>
        </div>
      </div>

      {/* View Switcher Controls */}
      <div className="bg-slate-50 border border-slate-200/60 rounded-2xl p-2.5 flex flex-col sm:flex-row justify-between items-center gap-3.5 shadow-xs">
        <div className="flex bg-slate-200/60 p-1.5 rounded-xl gap-1 w-full sm:w-auto">
          <button
            onClick={() => setViewMode('board')}
            className={`flex-1 sm:flex-none px-4 py-2 rounded-lg font-sans text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-all ${
              viewMode === 'board'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/50'
            }`}
          >
            <Network className="w-4 h-4 text-amber-500" />
            <span>Visual Board (Drag & Drop)</span>
          </button>
          <button
            onClick={() => setViewMode('directory')}
            className={`flex-1 sm:flex-none px-4 py-2 rounded-lg font-sans text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-all ${
              viewMode === 'directory'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/50'
            }`}
          >
            <Users className="w-4 h-4 text-slate-500" />
            <span>Registry Directory</span>
          </button>
        </div>

        {viewMode === 'board' && (
          <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
            <span className="font-sans text-[10px] text-slate-500 hidden md:inline-block">
              💡 Tip: Drag & drop cards onto each other to connect relations!
            </span>
            <button
              onClick={handleAutoArrange}
              className="px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-sans text-xs font-bold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs transition-all"
            >
              <RefreshCw className="w-3.5 h-3.5 text-amber-500" />
              <span>Auto-Arrange Layout</span>
            </button>
          </div>
        )}
      </div>

      {/* Grid Splitter: Visual Lineage Inspector & Generational Directory */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* LINEAGE INSPECTOR PANEL */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white shadow-xl space-y-6 sticky top-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-2">
                <GitFork className="w-4 h-4 text-amber-400 rotate-180" />
                <h3 className="font-serif text-base font-bold text-slate-100">Lineage Inspector</h3>
              </div>
              <span className="font-sans text-[10px] font-black uppercase tracking-widest text-slate-400 bg-slate-800 px-2 py-1 rounded">Interactive</span>
            </div>

            {selectedMember ? (
              <div className="space-y-6">
                
                {/* 1. Parent Node Connectors */}
                <div className="space-y-2">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Parents</div>
                  <div className="grid grid-cols-2 gap-3">
                    {/* Father Card */}
                    {father ? (
                      <div 
                        onClick={() => setSelectedMemberId(father.id)}
                        className="p-3 bg-slate-800/60 border border-slate-700/50 hover:border-amber-400/30 rounded-2xl cursor-pointer transition-all hover:bg-slate-800 flex items-center gap-2 min-w-0"
                      >
                        <div className="w-8 h-8 rounded-full border border-slate-700 bg-slate-800 flex-shrink-0 flex items-center justify-center font-sans font-bold text-[10px]">
                          {getInitials(father.name)}
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-[10px] text-slate-400 font-bold truncate">Father</p>
                          <p className="text-[11px] font-semibold text-slate-200 truncate">{father.name}</p>
                        </div>
                      </div>
                    ) : (
                      <button 
                        onClick={() => setLinkTarget({ memberId: selectedMember.id, type: 'father' })}
                        className="p-3 bg-slate-800/20 border border-dashed border-slate-700 hover:border-slate-500 rounded-2xl flex items-center justify-center text-slate-500 gap-1 text-[11px] font-bold transition-all hover:text-slate-300 cursor-pointer"
                      >
                        <Link2 className="w-3.5 h-3.5 text-amber-400" />
                        <span>Link Father</span>
                      </button>
                    )}

                    {/* Mother Card */}
                    {mother ? (
                      <div 
                        onClick={() => setSelectedMemberId(mother.id)}
                        className="p-3 bg-slate-800/60 border border-slate-700/50 hover:border-amber-400/30 rounded-2xl cursor-pointer transition-all hover:bg-slate-800 flex items-center gap-2 min-w-0"
                      >
                        <div className="w-8 h-8 rounded-full border border-slate-700 bg-slate-800 flex-shrink-0 flex items-center justify-center font-sans font-bold text-[10px]">
                          {getInitials(mother.name)}
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-[10px] text-slate-400 font-bold truncate">Mother</p>
                          <p className="text-[11px] font-semibold text-slate-200 truncate">{mother.name}</p>
                        </div>
                      </div>
                    ) : (
                      <button 
                        onClick={() => setLinkTarget({ memberId: selectedMember.id, type: 'mother' })}
                        className="p-3 bg-slate-800/20 border border-dashed border-slate-700 hover:border-slate-500 rounded-2xl flex items-center justify-center text-slate-500 gap-1 text-[11px] font-bold transition-all hover:text-slate-300 cursor-pointer"
                      >
                        <Link2 className="w-3.5 h-3.5 text-amber-400" />
                        <span>Link Mother</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* 2. Main Selected Node & Spouse (Linked side-by-side with Heart) */}
                <div className="bg-slate-800/40 border border-slate-800 rounded-2xl p-4 space-y-4">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center">Core Couple</div>
                  
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                    {/* Selected Person Card */}
                    <div className="w-full sm:w-1/2 p-3 bg-gradient-to-br from-slate-800 to-slate-900 border border-amber-400/40 rounded-2xl shadow-md text-center space-y-2 relative">
                      <div className="absolute -top-2 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full bg-amber-500 text-[8px] font-black uppercase text-slate-950 tracking-wider">
                        Active Selection
                      </div>
                      <div className="w-12 h-12 rounded-full border-2 border-amber-400 mx-auto flex items-center justify-center bg-slate-800 font-sans font-black text-xs">
                        {getInitials(selectedMember.name)}
                      </div>
                      <div>
                        <h4 className="text-xs font-extrabold text-slate-100 truncate">{selectedMember.name}</h4>
                        <p className="text-[10px] text-amber-400 font-medium">{selectedMember.relation}</p>
                      </div>
                    </div>

                    {/* Heart Connector */}
                    <div className="shrink-0">
                      <Heart className={`w-5 h-5 ${spouse ? 'text-red-500 fill-red-500 animate-pulse' : 'text-slate-600'}`} />
                    </div>

                    {/* Spouse Card */}
                    {spouse ? (
                      <div 
                        onClick={() => setSelectedMemberId(spouse.id)}
                        className="w-full sm:w-1/2 p-3 bg-slate-800 hover:bg-slate-750 border border-slate-700 rounded-2xl text-center space-y-2 cursor-pointer transition-all"
                      >
                        <div className="w-12 h-12 rounded-full border border-slate-600 mx-auto flex items-center justify-center bg-slate-800 font-sans font-bold text-xs">
                          {getInitials(spouse.name)}
                        </div>
                        <div>
                          <h4 className="text-xs font-bold text-slate-100 truncate">{spouse.name}</h4>
                          <p className="text-[10px] text-slate-400">Spouse</p>
                        </div>
                      </div>
                    ) : (
                      <button 
                        onClick={() => setLinkTarget({ memberId: selectedMember.id, type: 'spouse' })}
                        className="w-full sm:w-1/2 p-3 bg-slate-850 border border-dashed border-slate-750 hover:border-slate-600 text-slate-500 hover:text-slate-300 rounded-2xl flex flex-col items-center justify-center gap-1.5 text-[11px] font-bold transition-all aspect-square cursor-pointer"
                      >
                        <Link2 className="w-4 h-4 text-amber-400" />
                        <span>Link Partner</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* 3. Children Nodes list */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-widest">
                    <span className="text-slate-400">Offspring / Children ({children.length})</span>
                    <button
                      type="button"
                      onClick={() => setShowInlineChildForm(!showInlineChildForm)}
                      className="text-amber-400 hover:text-amber-300 font-bold flex items-center gap-0.5 cursor-pointer text-[9px] transition-all bg-slate-800 px-2 py-1 rounded hover:bg-slate-750 border border-slate-700/60"
                    >
                      {showInlineChildForm ? 'Cancel' : '+ Quick Add'}
                    </button>
                  </div>

                  {showInlineChildForm && (
                    <div className="p-3.5 bg-slate-850/80 border border-amber-500/25 rounded-2xl space-y-3 animate-fade-in shadow-lg">
                      <div className="text-[10px] text-amber-400 font-bold flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5 animate-pulse" />
                        <span>Add child to {selectedMember.name}</span>
                      </div>
                      <div className="space-y-2">
                        <input
                          type="text"
                          placeholder="Child's Full Name"
                          value={inlineChildName}
                          onChange={(e) => setInlineChildName(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 focus:border-amber-400 rounded-lg px-2.5 py-1.5 text-xs text-white outline-none"
                        />
                        <div className="grid grid-cols-2 gap-2">
                          <select
                            value={inlineChildRelation}
                            onChange={(e) => setInlineChildRelation(e.target.value as 'Son' | 'Daughter')}
                            className="w-full bg-slate-900 border border-slate-700 focus:border-amber-400 rounded-lg px-2 py-1 text-xs text-white outline-none"
                          >
                            <option value="Son">Son</option>
                            <option value="Daughter">Daughter</option>
                          </select>
                          <input
                            type="number"
                            placeholder="Birth Year"
                            value={inlineChildBirthYear}
                            onChange={(e) => setInlineChildBirthYear(e.target.value)}
                            className="w-full bg-slate-900 border border-slate-700 focus:border-amber-400 rounded-lg px-2 py-1 text-xs text-white outline-none"
                          />
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={handleCreateInlineChild}
                        className="w-full py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Create Child Node</span>
                      </button>
                    </div>
                  )}

                  {children.length > 0 ? (
                    <div className="grid grid-cols-1 gap-2">
                      {children.map(child => (
                        <div 
                          key={child.id}
                          onClick={() => setSelectedMemberId(child.id)}
                          className="p-3 bg-slate-800/40 border border-slate-800 hover:border-amber-400/30 rounded-xl cursor-pointer transition-all hover:bg-slate-800 flex items-center justify-between min-w-0"
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <div className="w-8 h-8 rounded-full border border-slate-700 bg-slate-800 flex-shrink-0 flex items-center justify-center font-sans font-bold text-[10px]">
                              {getInitials(child.name)}
                            </div>
                            <div className="min-w-0">
                              <p className="text-xs font-bold text-slate-200 truncate">{child.name}</p>
                              <p className="text-[9px] text-slate-400">{child.relation}</p>
                            </div>
                          </div>
                          <span className="text-[9px] font-mono text-slate-500 font-bold">Child node</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center p-4 bg-slate-800/10 border border-dashed border-slate-800 rounded-xl text-[11px] text-slate-500 font-medium">
                      No registered children nodes linked to this member.
                    </div>
                  )}
                </div>

                {/* 4. Sibling quick-swap */}
                <div className="space-y-2 pt-2">
                  <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-widest">
                    <span className="text-slate-400">Siblings ({siblings.length})</span>
                    <button
                      type="button"
                      onClick={() => setShowInlineSiblingForm(!showInlineSiblingForm)}
                      className="text-amber-400 hover:text-amber-300 font-bold flex items-center gap-0.5 cursor-pointer text-[9px] transition-all bg-slate-800 px-2 py-1 rounded hover:bg-slate-750 border border-slate-700/60"
                    >
                      {showInlineSiblingForm ? 'Cancel' : '+ Quick Add'}
                    </button>
                  </div>

                  {showInlineSiblingForm && (
                    <div className="p-3.5 bg-slate-850/80 border border-amber-500/25 rounded-2xl space-y-3 animate-fade-in shadow-lg">
                      <div className="text-[10px] text-amber-400 font-bold flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5 animate-pulse" />
                        <span>Add sibling to {selectedMember.name}</span>
                      </div>
                      <div className="space-y-2">
                        <input
                          type="text"
                          placeholder="Sibling's Full Name"
                          value={inlineSiblingName}
                          onChange={(e) => setInlineSiblingName(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 focus:border-amber-400 rounded-lg px-2.5 py-1.5 text-xs text-white outline-none"
                        />
                        <div className="grid grid-cols-2 gap-2">
                          <select
                            value={inlineSiblingRelation}
                            onChange={(e) => setInlineSiblingRelation(e.target.value as 'Brother' | 'Sister')}
                            className="w-full bg-slate-900 border border-slate-700 focus:border-amber-400 rounded-lg px-2 py-1 text-xs text-white outline-none"
                          >
                            <option value="Brother">Brother</option>
                            <option value="Sister">Sister</option>
                          </select>
                          <input
                            type="number"
                            placeholder="Birth Year"
                            value={inlineSiblingBirthYear}
                            onChange={(e) => setInlineSiblingBirthYear(e.target.value)}
                            className="w-full bg-slate-900 border border-slate-700 focus:border-amber-400 rounded-lg px-2 py-1 text-xs text-white outline-none"
                          />
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={handleCreateInlineSibling}
                        className="w-full py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Create Sibling Node</span>
                      </button>
                    </div>
                  )}

                  {siblings.length > 0 ? (
                    <div className="flex flex-wrap gap-1.5">
                      {siblings.map(sib => (
                        <button 
                          key={sib.id}
                          onClick={() => setSelectedMemberId(sib.id)}
                          className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-750 text-slate-300 rounded-lg text-[10px] font-bold transition-all cursor-pointer"
                        >
                          {sib.name} ({sib.relation})
                        </button>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center p-3 bg-slate-800/10 border border-dashed border-slate-800 rounded-xl text-[10px] text-slate-500">
                      No sibling nodes listed. Click quick add above to insert.
                    </div>
                  )}
                </div>

                {/* 5. Biography & Metadata */}
                <div className="pt-4 border-t border-slate-800 space-y-3">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-400 font-medium">Status:</span>
                    <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${selectedMember.isAlive ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-slate-700/20 text-slate-400'}`}>
                      {selectedMember.isAlive ? 'Alive & Well' : 'In Eternal Remembrance'}
                    </span>
                  </div>

                  {selectedMember.birthYear && (
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-400 font-medium">Birth Year:</span>
                      <span className="text-slate-200 font-bold">{selectedMember.birthYear}</span>
                    </div>
                  )}

                  {selectedMember.location && (
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-400 font-medium">Location:</span>
                      <span className="text-slate-200 font-bold flex items-center gap-0.5">
                        <MapPin className="w-3 h-3 text-red-400" />
                        {selectedMember.location}
                      </span>
                    </div>
                  )}

                  {selectedMember.bio && (
                    <div className="p-3 bg-slate-800/30 rounded-xl border border-slate-800 text-[11px] text-slate-300 leading-relaxed italic font-serif">
                      "{selectedMember.bio}"
                    </div>
                  )}

                  {/* Actions: Unlink Panel */}
                  <div className="pt-2 flex flex-col gap-1.5">
                    {father && (
                      <button 
                        onClick={() => handleRemoveRelation(selectedMember.id, 'father')}
                        className="w-full text-left px-2.5 py-1.5 bg-red-950/20 hover:bg-red-950/40 text-red-300 border border-red-900/30 hover:border-red-800/40 rounded-xl text-[10px] font-bold transition-all flex items-center justify-between cursor-pointer"
                      >
                        <span>Disconnect Father linkage</span>
                        <UserMinus className="w-3.5 h-3.5" />
                      </button>
                    )}
                    {mother && (
                      <button 
                        onClick={() => handleRemoveRelation(selectedMember.id, 'mother')}
                        className="w-full text-left px-2.5 py-1.5 bg-red-950/20 hover:bg-red-950/40 text-red-300 border border-red-900/30 hover:border-red-800/40 rounded-xl text-[10px] font-bold transition-all flex items-center justify-between cursor-pointer"
                      >
                        <span>Disconnect Mother linkage</span>
                        <UserMinus className="w-3.5 h-3.5" />
                      </button>
                    )}
                    {spouse && (
                      <button 
                        onClick={() => handleRemoveRelation(selectedMember.id, 'spouse')}
                        className="w-full text-left px-2.5 py-1.5 bg-red-950/20 hover:bg-red-950/40 text-red-300 border border-red-900/30 hover:border-red-800/40 rounded-xl text-[10px] font-bold transition-all flex items-center justify-between cursor-pointer"
                      >
                        <span>Disconnect Spouse linkage</span>
                        <UserMinus className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

              </div>
            ) : (
              <div className="text-center py-12 text-slate-500 text-xs">
                <Users className="w-8 h-8 mx-auto text-slate-700 mb-2" />
                <span>Select any person card in the family registry directory to load and edit their interactive lineage tree.</span>
              </div>
            )}
          </div>
        </div>

        {/* RIGHT AREA: VISUAL BOARD OR REGISTRY DIRECTORY */}
        <div className="lg:col-span-2 space-y-8">
          
          {viewMode === 'board' ? (
            <div className="space-y-4">
              {/* Board Canvas Wrapper */}
              <div className="relative overflow-hidden border border-slate-800 bg-slate-950 rounded-3xl shadow-2xl h-[720px] w-full flex flex-col">
                
                {/* Board Canvas Scroll Area */}
                <div 
                  ref={canvasRef}
                  className="flex-1 overflow-auto p-4 select-none relative scrollbar-thin scrollbar-thumb-slate-850 scrollbar-track-transparent"
                  style={{
                    backgroundImage: 'radial-gradient(rgba(255, 255, 255, 0.08) 1px, transparent 1px)',
                    backgroundSize: '24px 24px',
                  }}
                >
                  {/* Absolute sizing stage */}
                  <div 
                    className="w-[1200px] h-[920px] relative"
                    id="canvas-stage-area"
                    onDoubleClick={(e) => {
                      if (e.target === e.currentTarget) {
                        const rect = e.currentTarget.getBoundingClientRect();
                        const x = e.clientX - rect.left;
                        const y = e.clientY - rect.top;
                        setDoubleClickedPos({ x, y });
                        setIsAddOpen(true);
                        showToast("Opening form to create member at this visual location!", "info");
                      }
                    }}
                  >
                    
                    {/* SVG Connector lines */}
                    <svg className="absolute inset-0 pointer-events-none w-[1200px] h-[920px]">
                      {(() => {
                        const lines: JSX.Element[] = [];
                        const spouseConnectionsRendered = new Set<string>();

                        members.forEach(member => {
                          const pos = resolvedPositions[member.id];
                          if (!pos) return;

                          const cx = pos.x + 95;
                          const cy = pos.y + 45;

                          // 1. Mother connection (curved path)
                          if (member.motherId) {
                            const mPos = resolvedPositions[member.motherId];
                            if (mPos) {
                              const mcx = mPos.x + 95;
                              const mcy = mPos.y + 90;
                              const childTopX = cx;
                              const childTopY = pos.y;
                              
                              const pathD = `M ${mcx} ${mcy} C ${mcx} ${(mcy + childTopY) / 2}, ${childTopX} ${(mcy + childTopY) / 2}, ${childTopX} ${childTopY}`;
                              lines.push(
                                <path
                                  key={`mother-${member.id}`}
                                  d={pathD}
                                  fill="none"
                                  stroke="#fb7185" // maternal (rose-400)
                                  strokeWidth="2.5"
                                  strokeLinecap="round"
                                  className="opacity-45 hover:opacity-80 transition-opacity animate-pulse"
                                />
                              );
                            }
                          }

                          // 2. Father connection (curved path)
                          if (member.fatherId) {
                            const fPos = resolvedPositions[member.fatherId];
                            if (fPos) {
                              const fcx = fPos.x + 95;
                              const fcy = fPos.y + 90;
                              const childTopX = cx;
                              const childTopY = pos.y;
                              
                              const pathD = `M ${fcx} ${fcy} C ${fcx} ${(fcy + childTopY) / 2}, ${childTopX} ${(fcy + childTopY) / 2}, ${childTopX} ${childTopY}`;
                              lines.push(
                                <path
                                  key={`father-${member.id}`}
                                  d={pathD}
                                  fill="none"
                                  stroke="#38bdf8" // paternal (sky-400)
                                  strokeWidth="2.5"
                                  strokeLinecap="round"
                                  className="opacity-45 hover:opacity-80 transition-opacity animate-pulse"
                                />
                              );
                            }
                          }

                          // 3. Spouse connection (dashed line with heart)
                          if (member.spouseId) {
                            const key = [member.id, member.spouseId].sort().join('-');
                            if (!spouseConnectionsRendered.has(key)) {
                              spouseConnectionsRendered.add(key);
                              const sPos = resolvedPositions[member.spouseId];
                              if (sPos) {
                                const scx = sPos.x + 95;
                                const scy = sPos.y + 45;
                                
                                let startX = cx;
                                let startY = cy;
                                let endX = scx;
                                let endY = scy;
                                
                                if (pos.x + 190 < sPos.x) {
                                  startX = pos.x + 190;
                                  endX = sPos.x;
                                } else if (sPos.x + 190 < pos.x) {
                                  startX = pos.x;
                                  endX = sPos.x + 190;
                                }
                                
                                lines.push(
                                  <g key={`spouse-group-${key}`}>
                                    <path
                                      d={`M ${startX} ${startY} C ${(startX + endX)/2} ${startY}, ${(startX + endX)/2} ${endY}, ${endX} ${endY}`}
                                      fill="none"
                                      stroke="#f43f5e"
                                      strokeWidth="2.5"
                                      strokeDasharray="4 3"
                                      className="opacity-60"
                                    />
                                    {/* Small floating heart icon between spouses */}
                                    <g transform={`translate(${(startX + endX) / 2 - 8}, ${(startY + endY) / 2 - 8})`}>
                                      <path 
                                        d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" 
                                        fill="#f43f5e" 
                                        transform="scale(0.7)"
                                        className="origin-center animate-pulse"
                                      />
                                    </g>
                                  </g>
                                );
                              }
                            }
                          }
                        });

                        return lines;
                      })()}
                    </svg>

                    {/* Draggable Cards */}
                    {members.map(member => {
                      const pos = resolvedPositions[member.id];
                      const isSelected = selectedMemberId === member.id;
                      const isDragging = draggingId === member.id;
                      
                      // Filter dimming
                      const matchesSearch = !searchQuery || 
                        member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                        member.relation.toLowerCase().includes(searchQuery.toLowerCase());

                      const spouseName = member.spouseId ? getMemberById(member.spouseId)?.name : null;
                      
                      return (
                        <div
                          key={member.id}
                          onMouseDown={(e) => handleMouseDown(e, member.id)}
                          onTouchStart={(e) => handleTouchStart(e, member.id)}
                          style={{
                            position: 'absolute',
                            left: `${pos?.x || 100}px`,
                            top: `${pos?.y || 100}px`,
                            width: '190px',
                            height: '105px',
                            zIndex: isDragging ? 40 : isSelected ? 30 : 20,
                          }}
                          className={`${
                            member.isAlive 
                              ? 'bg-slate-900 border-slate-800/80 text-white shadow-lg' 
                              : 'bg-gradient-to-b from-slate-950 to-amber-950/20 border-amber-600/40 text-amber-50 shadow-[0_0_15px_rgba(217,119,6,0.12)]'
                          } border rounded-2xl p-3 flex flex-col justify-between transition-all select-none group ${
                            isDragging 
                              ? 'cursor-grabbing scale-105 shadow-2xl opacity-95 border-amber-400' 
                              : 'cursor-grab hover:border-slate-500'
                          } ${
                            isSelected 
                              ? 'border-amber-400 shadow-[0_0_12px_rgba(251,191,36,0.25)] ring-1 ring-amber-400/50' 
                              : ''
                          } ${
                            !matchesSearch ? 'opacity-35 grayscale-[40%]' : ''
                          }`}
                        >
                          <div className="flex gap-2.5 items-start min-w-0">
                            {/* Fallback avatar */}
                            <div className={`w-8 h-8 rounded-full overflow-hidden flex-shrink-0 flex items-center justify-center font-sans font-black text-[10px] ${
                              member.isAlive 
                                ? 'bg-slate-800 border border-slate-700 text-amber-400' 
                                : 'bg-amber-950/80 border border-amber-800 text-amber-300 font-serif'
                            }`}>
                              {member.avatar ? (
                                <img 
                                  src={member.avatar} 
                                  alt={member.name} 
                                  referrerPolicy="no-referrer"
                                  className="w-full h-full object-cover animate-fade-in" 
                                />
                              ) : (
                                getInitials(member.name)
                              )}
                            </div>
                            
                            <div className="min-w-0 flex-1 font-sans">
                              <h4 className="text-[11px] font-extrabold text-slate-100 truncate tracking-tight flex items-center gap-1">
                                <span className="truncate">{member.name}</span>
                                {!member.isAlive && <span title="Eternal Diya Tribute" className="text-amber-500 animate-pulse shrink-0">🪔</span>}
                              </h4>
                              <p className="text-[9px] text-amber-400 font-black uppercase tracking-widest leading-none mt-0.5">{member.relation}</p>
                              
                              {spouseName && (
                                <div className="text-[8.5px] text-rose-400 font-bold flex items-center gap-1 mt-1 truncate">
                                  <Heart className="w-2.5 h-2.5 fill-rose-500/80 text-rose-500 shrink-0" />
                                  <span className="truncate">Spouse: {spouseName}</span>
                                </div>
                              )}
                            </div>
                          </div>

                          <div className="flex items-center justify-between mt-1 text-[9px] text-slate-400 font-medium border-t border-slate-800/60 pt-1.5 font-sans">
                            {member.isAlive ? (
                              <span className="truncate max-w-[100px] text-slate-400">
                                {member.location || 'No Location'}
                              </span>
                            ) : (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setMemoriesModalMember(member);
                                }}
                                className="text-[8px] px-1.5 py-0.5 rounded bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 font-bold flex items-center gap-1 transition-all cursor-pointer hover:scale-105"
                              >
                                <Flame className="w-2.5 h-2.5 text-amber-500 fill-amber-500 animate-pulse" />
                                <span>Memories ({member.memories?.length || 0})</span>
                              </button>
                            )}
                            <span className="font-mono text-slate-500 font-bold">
                              {member.isAlive ? (member.birthYear || '—') : `${member.birthYear || '—'} - ${member.deathYear || '🪔'}`}
                            </span>
                          </div>

                          {/* Quick delete button hidden unless hovered */}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteMember(member.id, e);
                            }}
                            className="absolute -top-1.5 -right-1.5 p-1 bg-slate-950 border border-slate-800 hover:border-red-500 hover:bg-red-950/40 text-slate-400 hover:text-red-400 rounded-full cursor-pointer transition-all opacity-0 group-hover:opacity-100 shadow-md"
                            title="Delete member"
                          >
                            <X className="w-2.5 h-2.5" />
                          </button>
                        </div>
                      );
                    })}

                  </div>
                </div>

                {/* Legend overlay footer */}
                <div className="px-5 py-3 border-t border-slate-850 bg-slate-900/80 flex flex-wrap gap-x-5 gap-y-2 text-[10px] font-sans font-bold uppercase tracking-wider text-slate-400">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
                    <span>Father Lineage</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-rose-400 animate-pulse" />
                    <span>Mother Lineage</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                    <span>Spouse Connection</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-amber-400">
                    <span>🪔</span>
                    <span>Diya Tribute</span>
                  </div>
                </div>

              </div>
            </div>
          ) : (
            <div className="space-y-10">
              
              {/* Removed old inline selector. Replaced with global modern relationship modal. */}

              {/* Generational Accordion Groupings */}
              <div className="space-y-10">
                {GENERATION_PRESETS.map(gen => {
                  const genMembers = filteredMembers.filter(m => {
                    let rel = m.relation;
                    if (rel === 'Spouse' && m.spouseId) {
                      const partner = members.find(p => p.id === m.spouseId);
                      if (partner && partner.relation !== 'Spouse') rel = partner.relation;
                    }
                    return gen.relations.includes(rel);
                  });
                  if (genMembers.length === 0) return null;

                  return (
                    <div key={gen.id} className="space-y-4">
                      
                      {/* Generational Ribbon */}
                      <div className="flex items-center gap-2.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shadow-sm" />
                        <h3 className="font-serif text-sm font-extrabold text-slate-950 uppercase tracking-wider">{gen.title}</h3>
                        <span className="font-mono text-[10px] text-slate-400 bg-slate-50 border border-slate-200/50 px-2 py-0.5 rounded">
                          {genMembers.length} {genMembers.length === 1 ? 'member' : 'members'}
                        </span>
                      </div>

                      {/* Cards Grid */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {genMembers.map(member => {
                          const isSelected = selectedMemberId === member.id;
                          const hasLinkedSpouse = !!member.spouseId;

                          return (
                            <div
                              key={member.id}
                              onClick={() => setSelectedMemberId(member.id)}
                              className={`border rounded-2xl p-5 hover:shadow-md transition-all duration-300 flex flex-col justify-between cursor-pointer relative group ${
                                member.isAlive 
                                  ? 'bg-white border-outline-variant/30 hover:border-slate-300' 
                                  : 'bg-gradient-to-br from-white to-amber-50/20 border-amber-500/20 hover:border-amber-500/40'
                              } ${
                                isSelected 
                                  ? 'border-slate-900 shadow-sm ring-1 ring-slate-900' 
                                  : ''
                              }`}
                            >
                              <div className="flex gap-4">
                                <div className={`w-14 h-14 rounded-full overflow-hidden shrink-0 border relative select-none ${
                                  member.isAlive ? 'border-slate-100 bg-slate-50' : 'border-amber-200/50 bg-amber-50/50'
                                }`}>
                                  {member.avatar ? (
                                    <img 
                                      src={member.avatar} 
                                      alt={member.name} 
                                      referrerPolicy="no-referrer"
                                      className="w-full h-full object-cover animate-fade-in" 
                                    />
                                  ) : (
                                    <div className={`w-full h-full flex items-center justify-center font-sans font-black text-xs uppercase ${
                                      member.isAlive 
                                        ? 'bg-gradient-to-br from-slate-100 to-slate-200 text-slate-700' 
                                        : 'bg-gradient-to-br from-amber-100 to-amber-200 text-amber-800 font-serif'
                                    }`}>
                                      {getInitials(member.name)}
                                    </div>
                                  )}
                                  <span className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white ${
                                    member.isAlive ? 'bg-green-500' : 'bg-amber-600 shadow-[0_0_6px_rgba(217,119,6,0.4)]'
                                  }`} />
                                </div>

                                <div className="min-w-0 flex-1">
                                  <div className="flex items-start justify-between gap-2">
                                    <h4 className="font-sans text-xs font-black text-slate-900 truncate group-hover:text-amber-600 transition-colors flex items-center gap-1">
                                      <span className="truncate">{member.name}</span>
                                      {!member.isAlive && <span title="Eternal Diya Tribute">🪔</span>}
                                    </h4>
                                    <button
                                      onClick={(e) => handleDeleteMember(member.id, e)}
                                      className="p-1 rounded text-slate-400 hover:text-red-500 hover:bg-red-50 opacity-0 group-hover:opacity-100 transition-all cursor-pointer shrink-0"
                                      title="Delete family member"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                  <p className="font-sans text-[10px] text-amber-600 font-black uppercase tracking-wider">{member.relation}</p>
                                  
                                  {hasLinkedSpouse && (
                                    <p className="font-sans text-[10px] text-rose-500 font-bold flex items-center gap-1 mt-1 truncate">
                                      <Heart className="w-3 h-3 fill-rose-500/80 text-rose-500 shrink-0" />
                                      <span className="truncate">Spouse: {getMemberById(member.spouseId)?.name}</span>
                                    </p>
                                  )}
                                  
                                  <div className="flex flex-col gap-1 mt-2.5 text-[11px] text-on-surface-variant font-medium">
                                    {member.birthYear && (
                                      <span className="flex items-center gap-1 font-mono text-[10px]">
                                        <Calendar className="w-3 h-3 text-slate-400 shrink-0" />
                                        <span>
                                          {member.isAlive 
                                            ? `Born: ${member.birthYear}` 
                                            : `Lifespan: ${member.birthYear} - ${member.deathYear || '🪔'}`}
                                        </span>
                                      </span>
                                    )}
                                    {member.isAlive && member.location && (
                                      <span className="flex items-center gap-1 truncate">
                                        <MapPin className="w-3 h-3 text-red-400 shrink-0" />
                                        {member.location}
                                      </span>
                                    )}
                                    {!member.isAlive && (
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          setMemoriesModalMember(member);
                                        }}
                                        className="mt-1 flex items-center gap-1 text-[9px] text-amber-700 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 px-2 py-0.5 rounded-full font-bold transition-all w-fit cursor-pointer"
                                      >
                                        <Flame className="w-3 h-3 text-amber-500 fill-amber-500 animate-pulse" />
                                        <span>Memories ({member.memories?.length || 0})</span>
                                      </button>
                                    )}
                                  </div>
                                </div>
                              </div>

                              <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap gap-1.5 items-center justify-between text-[9px] font-sans font-bold uppercase tracking-wider">
                                <span className="text-slate-400">Registry Connectors:</span>
                                <div className="flex flex-wrap gap-1.5">
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      if (member.spouseId) {
                                        setSelectedMemberId(member.spouseId);
                                        showToast(`Selected spouse: ${getMemberById(member.spouseId)?.name}`);
                                      } else {
                                        setLinkTarget({ memberId: member.id, type: 'spouse' });
                                        setSelectedMemberId(member.id);
                                      }
                                    }}
                                    className={`px-2 py-0.5 rounded-full border cursor-pointer hover:scale-105 transition-all text-[9px] font-sans font-bold uppercase tracking-wider ${
                                      hasLinkedSpouse 
                                        ? 'bg-rose-50 text-rose-600 border-rose-100 hover:bg-rose-100/70' 
                                        : 'bg-slate-50 text-slate-400 border-slate-100 hover:bg-slate-100 hover:text-slate-600'
                                    }`}
                                    title={member.spouseId ? `View Spouse: ${getMemberById(member.spouseId)?.name}` : 'Link Spouse'}
                                  >
                                    Spouse {hasLinkedSpouse ? '✓' : '•'}
                                  </button>
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      if (member.fatherId) {
                                        setSelectedMemberId(member.fatherId);
                                        showToast(`Selected father: ${getMemberById(member.fatherId)?.name}`);
                                      } else {
                                        setLinkTarget({ memberId: member.id, type: 'father' });
                                        setSelectedMemberId(member.id);
                                      }
                                    }}
                                    className={`px-2 py-0.5 rounded-full border cursor-pointer hover:scale-105 transition-all text-[9px] font-sans font-bold uppercase tracking-wider ${
                                      member.fatherId 
                                        ? 'bg-sky-50 text-sky-600 border-sky-100 hover:bg-sky-100/70' 
                                        : 'bg-slate-50 text-slate-400 border-slate-100 hover:bg-slate-100 hover:text-slate-600'
                                    }`}
                                    title={member.fatherId ? `View Father: ${getMemberById(member.fatherId)?.name}` : 'Link Father'}
                                  >
                                    Father {member.fatherId ? '✓' : '•'}
                                  </button>
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      if (member.motherId) {
                                        setSelectedMemberId(member.motherId);
                                        showToast(`Selected mother: ${getMemberById(member.motherId)?.name}`);
                                      } else {
                                        setLinkTarget({ memberId: member.id, type: 'mother' });
                                        setSelectedMemberId(member.id);
                                      }
                                    }}
                                    className={`px-2 py-0.5 rounded-full border cursor-pointer hover:scale-105 transition-all text-[9px] font-sans font-bold uppercase tracking-wider ${
                                      member.motherId 
                                        ? 'bg-pink-50 text-pink-600 border-pink-100 hover:bg-pink-100/70' 
                                        : 'bg-slate-50 text-slate-400 border-slate-100 hover:bg-slate-100 hover:text-slate-600'
                                    }`}
                                    title={member.motherId ? `View Mother: ${getMemberById(member.motherId)?.name}` : 'Link Mother'}
                                  >
                                    Mother {member.motherId ? '✓' : '•'}
                                  </button>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>

            </div>
          )}

        </div>

      </div>

      {/* DRAG-DROP LINK CONFIRMATION MODAL */}
      {dropLinkTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl overflow-hidden border border-slate-100 flex flex-col p-6 animate-fade-in space-y-5">
            <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
              <div className="p-2 bg-amber-50 rounded-xl text-amber-600 border border-amber-200/50">
                <Link2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-serif text-base font-bold text-gray-900">Establish Relationship</h3>
                <p className="font-sans text-[10px] text-slate-500 uppercase tracking-widest font-extrabold">Drag & Drop Linker</p>
              </div>
            </div>

            <div className="font-sans text-xs text-slate-600 leading-relaxed">
              You dropped <span className="font-extrabold text-slate-900">
                {members.find(m => m.id === dropLinkTarget.sourceId)?.name}
              </span> on top of <span className="font-extrabold text-slate-900">
                {members.find(m => m.id === dropLinkTarget.targetId)?.name}
              </span>.
              <p className="mt-2 text-[11px] text-slate-500">
                Select how these two relatives are connected:
              </p>
            </div>

            <div className="grid grid-cols-1 gap-2.5">
              <button
                onClick={() => handleDropLinkRelation('spouse')}
                className="w-full py-3 px-4 bg-rose-50 border border-rose-200 hover:bg-rose-100/70 text-rose-700 text-xs font-bold rounded-2xl cursor-pointer transition-all flex items-center justify-between"
              >
                <span>They are Spouses / Partners</span>
                <Heart className="w-4 h-4 fill-rose-500 text-rose-500 animate-pulse" />
              </button>
              
              <button
                onClick={() => handleDropLinkRelation('father')}
                className="w-full py-3 px-4 bg-sky-50 border border-sky-200 hover:bg-sky-100/70 text-sky-700 text-xs font-bold rounded-2xl cursor-pointer transition-all flex items-center justify-between"
              >
                <span>The destination relative is their Father</span>
                <span className="text-[10px] bg-sky-100 text-sky-800 px-2 py-0.5 rounded-md font-mono">Paternal</span>
              </button>

              <button
                onClick={() => handleDropLinkRelation('mother')}
                className="w-full py-3 px-4 bg-pink-50 border border-pink-200 hover:bg-pink-100/70 text-pink-700 text-xs font-bold rounded-2xl cursor-pointer transition-all flex items-center justify-between"
              >
                <span>The destination relative is their Mother</span>
                <span className="text-[10px] bg-pink-100 text-pink-800 px-2 py-0.5 rounded-md font-mono">Maternal</span>
              </button>
            </div>

            <div className="flex gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => setDropLinkTarget(null)}
                className="w-full py-2.5 bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200 text-xs font-bold rounded-xl cursor-pointer transition-all text-center"
              >
                Cancel & Keep Separated
              </button>
            </div>
          </div>
        </div>
      )}

      {/* FULL DETAILED INTERACTIVE ADD MEMBER MODAL DIALOG */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden border border-slate-100 flex flex-col max-h-[90vh] my-4 animate-fade-in">
            
            <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <div className="flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-amber-500" />
                <h3 className="font-serif text-base font-bold text-gray-900">Add New Family Member</h3>
              </div>
              <button 
                onClick={() => setIsAddOpen(false)}
                className="p-1.5 rounded-full hover:bg-slate-200 text-slate-500 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddMember} className="p-6 overflow-y-auto space-y-5 flex-1">
              
              {/* Full Name */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Anand Nimmagadda"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-4 py-2.5 text-xs font-medium focus:ring-0 outline-none"
                />
              </div>

              {/* Relationship & Birth Year */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Relation to Hub</label>
                  <select
                    value={formRelation}
                    onChange={(e) => setFormRelation(e.target.value as FamilyMember['relation'])}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-3 py-2.5 text-xs font-medium focus:ring-0 outline-none"
                  >
                    {RELATION_OPTIONS.map(opt => (
                      <option key={opt} value={opt}>{opt}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Birth Year</label>
                  <input
                    type="number"
                    placeholder="e.g. 1992"
                    value={formBirthYear}
                    onChange={(e) => setFormBirthYear(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-4 py-2.5 text-xs font-medium focus:ring-0 outline-none"
                  />
                </div>
              </div>

              {/* Location & Status */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Current Location</label>
                  <input
                    type="text"
                    placeholder="e.g. Visakhapatnam, India"
                    value={formLocation}
                    onChange={(e) => setFormLocation(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-4 py-2.5 text-xs font-medium focus:ring-0 outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Status</label>
                  <div className="flex gap-4 pt-2 text-xs font-semibold text-slate-700">
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="radio"
                        checked={formIsAlive === true}
                        onChange={() => setFormIsAlive(true)}
                        className="text-amber-500 focus:ring-0"
                      />
                      <span>Alive & Well 🟢</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="radio"
                        checked={formIsAlive === false}
                        onChange={() => setFormIsAlive(false)}
                        className="text-amber-500 focus:ring-0"
                      />
                      <span>Deceased ⚪</span>
                    </label>
                  </div>
                </div>
              </div>

              {!formIsAlive && (
                <div className="space-y-1.5 animate-in fade-in slide-in-from-top-1 duration-200">
                  <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Year of Passing (Death Year)</label>
                  <input
                    type="number"
                    placeholder="e.g. 2014"
                    value={formDeathYear}
                    onChange={(e) => setFormDeathYear(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-4 py-2.5 text-xs font-medium focus:ring-0 outline-none"
                  />
                </div>
              )}

              {/* Bio Notes */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Biography / Notes</label>
                <textarea
                  rows={2}
                  placeholder="Tell us about their profession, hobbies, or unique characteristics..."
                  value={formBio}
                  onChange={(e) => setFormBio(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-4 py-2.5 text-xs font-medium focus:ring-0 outline-none resize-none"
                />
              </div>

              {/* OPTIONAL DIRECT RELATIONS BINDING */}
              <div className="border-t border-slate-100 pt-4 space-y-3.5">
                <div className="flex items-center gap-1.5">
                  <Link2 className="w-4 h-4 text-slate-500" />
                  <span className="font-serif text-xs font-bold text-slate-800 uppercase tracking-wider">Direct Tree Linkages (Optional)</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Father dropdown */}
                  <div className="space-y-1">
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wide">Father</label>
                    <select
                      value={formFatherId}
                      onChange={(e) => setFormFatherId(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs outline-none"
                    >
                      <option value="">-- Choose --</option>
                      {members.map(m => (
                        <option key={m.id} value={m.id}>{m.name}</option>
                      ))}
                    </select>
                  </div>

                  {/* Mother dropdown */}
                  <div className="space-y-1">
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wide">Mother</label>
                    <select
                      value={formMotherId}
                      onChange={(e) => setFormMotherId(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs outline-none"
                    >
                      <option value="">-- Choose --</option>
                      {members.map(m => (
                        <option key={m.id} value={m.id}>{m.name}</option>
                      ))}
                    </select>
                  </div>

                  {/* Spouse dropdown */}
                  <div className="space-y-1">
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wide">Spouse / Partner</label>
                    <select
                      value={formSpouseId}
                      onChange={(e) => setFormSpouseId(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs outline-none"
                    >
                      <option value="">-- Choose --</option>
                      {members.map(m => (
                        <option key={m.id} value={m.id}>{m.name}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Form CTA Buttons */}
              <div className="pt-4 border-t border-slate-100 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => { setIsAddOpen(false); setDoubleClickedPos(null); }}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-sans text-xs font-bold rounded-xl cursor-pointer transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-sans text-xs font-bold rounded-xl cursor-pointer transition-all flex items-center gap-1"
                >
                  <Check className="w-3.5 h-3.5 text-amber-400" />
                  <span>Create Member</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* GLOBAL LINK RELATION RELATIONSHIP MODAL */}
      {linkTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden border border-slate-100 flex flex-col max-h-[90vh] my-4 animate-fade-in">
            
            <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <div className="flex items-center gap-2">
                <Link2 className="w-5 h-5 text-amber-500" />
                <h3 className="font-serif text-base font-bold text-gray-900">
                  Link {linkTarget.type.toUpperCase()} for {members.find(m => m.id === linkTarget.memberId)?.name}
                </h3>
              </div>
              <button 
                onClick={() => {
                  setLinkTarget(null);
                  setLinkMode('existing');
                  setQuickName('');
                  setQuickBirthYear('');
                  setQuickIsAlive(true);
                  setQuickLocation('');
                }}
                className="p-1.5 rounded-full hover:bg-slate-200 text-slate-500 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Selection Tabs */}
            <div className="flex border-b border-slate-100 bg-slate-50/50 p-2 gap-1">
              <button
                type="button"
                onClick={() => setLinkMode('existing')}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                  linkMode === 'existing'
                    ? 'bg-white text-slate-900 shadow-xs border border-slate-200/50'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                Choose Existing Relative
              </button>
              <button
                type="button"
                onClick={() => setLinkMode('create')}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                  linkMode === 'create'
                    ? 'bg-white text-slate-900 shadow-xs border border-slate-200/50'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                ✨ Quick-Create New Relative
              </button>
            </div>

            <div className="p-6 overflow-y-auto max-h-[50vh] space-y-4">
              {linkMode === 'existing' ? (
                <div className="space-y-4">
                  <p className="font-sans text-xs text-slate-500 leading-normal">
                    Select an existing member from the registry to link as their <span className="font-bold text-slate-800">{linkTarget.type}</span>:
                  </p>
                  
                  {/* Search Bar for candidates */}
                  <div className="flex flex-col gap-2 max-h-[35vh] overflow-y-auto pr-1">
                    {members
                      .filter(m => m.id !== linkTarget.memberId)
                      .map(candidate => {
                        const spouse = candidate.spouseId ? members.find(m => m.id === candidate.spouseId) : null;
                        return (
                          <button
                            key={candidate.id}
                            type="button"
                            onClick={() => handleEstablishRelation(candidate.id)}
                            className="px-3.5 py-2.5 bg-slate-50 border border-slate-200 hover:border-amber-400 hover:bg-amber-50/35 hover:shadow-xs rounded-xl text-xs font-bold font-sans flex items-center justify-between cursor-pointer transition-all text-slate-700 w-full text-left"
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              <div className="w-6 h-6 rounded-full bg-slate-250 flex items-center justify-center font-bold text-[9px] text-slate-600 shrink-0">
                                {getInitials(candidate.name)}
                              </div>
                              <div className="min-w-0 flex flex-col">
                                <span className="truncate">{candidate.name}</span>
                                {spouse && (
                                  <span className="text-[10px] text-rose-500 font-medium flex items-center gap-0.5 mt-0.5">
                                    <Heart className="w-2.5 h-2.5 fill-rose-500/80 text-rose-500 shrink-0" />
                                    <span className="truncate">Spouse: {spouse.name}</span>
                                  </span>
                                )}
                              </div>
                            </div>
                            <span className="text-[10px] text-slate-400 font-mono font-bold bg-white border border-slate-150 px-2 py-0.5 rounded shrink-0">
                              {candidate.relation}
                            </span>
                          </button>
                        );
                      })}
                    {members.filter(m => m.id !== linkTarget.memberId).length === 0 && (
                      <div className="text-center py-6 w-full text-slate-500 text-xs">
                        No other members in the registry. Try using the quick-create option on the right tab!
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <p className="font-sans text-xs text-slate-500 leading-normal">
                    Fill in the details to instantly create, auto-position, and link a new <span className="font-bold text-slate-800 uppercase">{linkTarget.type}</span> node:
                  </p>

                  <div className="space-y-3.5">
                    {/* Name */}
                    <div className="space-y-1">
                      <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wide">Full Name *</label>
                      <input
                        type="text"
                        placeholder="e.g. Rama Nimmagadda"
                        value={quickName}
                        onChange={(e) => setQuickName(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-3 py-2 text-xs outline-none"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      {/* Birth Year */}
                      <div className="space-y-1">
                        <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wide">Birth Year (Optional)</label>
                        <input
                          type="number"
                          placeholder="e.g. 1956"
                          value={quickBirthYear}
                          onChange={(e) => setQuickBirthYear(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-3 py-2 text-xs outline-none"
                        />
                      </div>

                      {/* Location */}
                      <div className="space-y-1">
                        <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wide">Location (Optional)</label>
                        <input
                          type="text"
                          placeholder="e.g. Hyderabad"
                          value={quickLocation}
                          onChange={(e) => setQuickLocation(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-3 py-2 text-xs outline-none"
                        />
                      </div>
                    </div>

                    {/* Status */}
                    <div className="space-y-1">
                      <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wide">Status</label>
                      <div className="flex gap-4 pt-1 text-xs font-semibold text-slate-700">
                        <label className="flex items-center gap-1.5 cursor-pointer">
                          <input
                            type="radio"
                            checked={quickIsAlive === true}
                            onChange={() => setQuickIsAlive(true)}
                            className="text-amber-500 focus:ring-0"
                          />
                          <span>Alive & Well 🟢</span>
                        </label>
                        <label className="flex items-center gap-1.5 cursor-pointer">
                          <input
                            type="radio"
                            checked={quickIsAlive === false}
                            onChange={() => setQuickIsAlive(false)}
                            className="text-amber-500 focus:ring-0"
                          />
                          <span>Deceased ⚪</span>
                        </label>
                      </div>
                    </div>

                    {!quickIsAlive && (
                      <div className="space-y-1 animate-in fade-in slide-in-from-top-1 duration-200">
                        <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wide">Year of Passing (Death Year)</label>
                        <input
                          type="number"
                          placeholder="e.g. 2014"
                          value={quickDeathYear}
                          onChange={(e) => setQuickDeathYear(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-3 py-2 text-xs outline-none"
                        />
                      </div>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={handleQuickCreateAndLink}
                    className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer mt-2"
                  >
                    <Check className="w-4 h-4 text-amber-400" />
                    <span>Create & Link Instantly</span>
                  </button>
                </div>
              )}
            </div>

            <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setLinkTarget(null);
                  setLinkMode('existing');
                  setQuickName('');
                  setQuickBirthYear('');
                  setQuickIsAlive(true);
                  setQuickLocation('');
                }}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
              >
                Close
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Memories Modal */}
      {memoriesModalMember && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl p-6 border border-slate-150 animate-fade-in flex flex-col space-y-4">
            <div className="flex justify-between items-center border-b pb-3 border-slate-100">
              <h3 className="font-serif text-base font-bold text-slate-900">Memories of {memoriesModalMember.name}</h3>
              <button onClick={() => setMemoriesModalMember(null)} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
            </div>
            <div className="space-y-3 max-h-[50vh] overflow-y-auto pr-1">
              {memoriesModalMember.memories && memoriesModalMember.memories.length > 0 ? (
                memoriesModalMember.memories.map(m => (
                  <div key={m.id} className="p-3 bg-slate-50 border border-slate-100 rounded-xl space-y-1">
                    <p className="text-xs text-slate-700 italic font-serif">"{m.text}"</p>
                    <p className="text-[10px] text-slate-400 font-sans font-bold">— {m.author} ({m.date})</p>
                  </div>
                ))
              ) : (
                <p className="text-xs text-slate-500 italic text-center py-4">No registered memories for this relative yet.</p>
              )}
            </div>
            <div className="flex justify-end border-t pt-3 border-slate-100">
              <button onClick={() => setMemoriesModalMember(null)} className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold">
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
