import { useState, useEffect } from 'react';
import { 
  Users, 
  Search, 
  Edit, 
  Trash2, 
  Mail, 
  Phone, 
  MapPin, 
  Calendar, 
  Check, 
  X, 
  Heart, 
  Filter, 
  UserPlus, 
  ArrowUpDown,
  BookOpen,
  Upload
} from 'lucide-react';
import { FamilyMember } from '../types';

interface MembersTabProps {
  searchQuery: string;
}

const RELATION_OPTIONS = [
  'Self', 'Spouse', 'Father', 'Mother', 'Brother', 'Sister', 'Son', 'Daughter', 
  'Uncle', 'Aunt', 'Cousin', 'Grandfather', 'Grandmother', 'Great Grandfather', 'Great Grandmother', 'Other'
];

export default function MembersTab({ searchQuery: appSearchQuery }: MembersTabProps) {
  // Load initial members from localStorage (sharing state with FamilyTreeTab)
  const [members, setMembers] = useState<FamilyMember[]>(() => {
    const saved = localStorage.getItem('family_members_list');
    if (saved) {
      try {
        return JSON.parse(saved) as FamilyMember[];
      } catch (e) {
        console.error('Failed to parse family members list', e);
      }
    }
    return [];
  });

  // Local state for searching/filtering
  const [localSearch, setLocalSearch] = useState('');
  const [selectedRelation, setSelectedRelation] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<'All' | 'Alive' | 'Deceased'>('All');
  const [sortBy, setSortBy] = useState<'name' | 'birthYear'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // Modal / Form state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<FamilyMember | null>(null);
  const [deleteConfirmation, setDeleteConfirmation] = useState<{ id: string; name: string } | null>(null);
  
  // Form fields state
  const [formName, setFormName] = useState('');
  const [formRelation, setFormRelation] = useState<FamilyMember['relation']>('Self');
  const [formBirthYear, setFormBirthYear] = useState('');
  const [formIsAlive, setFormIsAlive] = useState(true);
  const [formDeathYear, setFormDeathYear] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formLocation, setFormLocation] = useState('');
  const [formBio, setFormBio] = useState('');
  const [formAvatar, setFormAvatar] = useState('');
  
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  // Sync state to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('family_members_list', JSON.stringify(members));
  }, [members]);

  // Handle toast timers
  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToast({ message, type });
  };

  // Handle local file uploads (converts to base64 DataURL for durable client persistence)
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 1.5 * 1024 * 1024) {
        showToast('Image size exceeds 1.5MB limit. Please upload a smaller image.', 'error');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setFormAvatar(reader.result);
          showToast('Photo uploaded successfully');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Open modal for adding
  const handleOpenAdd = () => {
    setEditingMember(null);
    setFormName('');
    setFormRelation('Self');
    setFormBirthYear('');
    setFormIsAlive(true);
    setFormDeathYear('');
    setFormEmail('');
    setFormPhone('');
    setFormLocation('');
    setFormBio('');
    setFormAvatar('');
    setIsModalOpen(true);
  };

  // Open modal for editing
  const handleOpenEdit = (member: FamilyMember) => {
    setEditingMember(member);
    setFormName(member.name);
    setFormRelation(member.relation);
    setFormBirthYear(member.birthYear ? String(member.birthYear) : '');
    setFormIsAlive(member.isAlive);
    setFormDeathYear(member.deathYear ? String(member.deathYear) : '');
    setFormEmail(member.email || '');
    setFormPhone(member.phone || '');
    setFormLocation(member.location || '');
    setFormBio(member.bio || '');
    setFormAvatar(member.avatar || '');
    setIsModalOpen(true);
  };

  // Save/Submit Form
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) {
      showToast('Please enter a name.', 'error');
      return;
    }

    const birthYearNum = formBirthYear ? parseInt(formBirthYear, 10) : undefined;
    const deathYearNum = !formIsAlive && formDeathYear ? parseInt(formDeathYear, 10) : undefined;

    if (editingMember) {
      // Edit existing
      setMembers(prev => prev.map(m => {
        if (m.id === editingMember.id) {
          return {
            ...m,
            name: formName.trim(),
            relation: formRelation,
            birthYear: birthYearNum,
            isAlive: formIsAlive,
            deathYear: deathYearNum,
            email: formEmail.trim() || undefined,
            phone: formPhone.trim() || undefined,
            location: formLocation.trim() || undefined,
            bio: formBio.trim() || undefined,
            avatar: formAvatar.trim() || undefined,
          };
        }
        return m;
      }));
      showToast(`Updated details for ${formName.trim()}`);
    } else {
      // Create new
      const newMember: FamilyMember = {
        id: `mem-${Date.now()}`,
        name: formName.trim(),
        relation: formRelation,
        birthYear: birthYearNum,
        isAlive: formIsAlive,
        deathYear: deathYearNum,
        email: formEmail.trim() || undefined,
        phone: formPhone.trim() || undefined,
        location: formLocation.trim() || undefined,
        bio: formBio.trim() || undefined,
        avatar: formAvatar.trim() || undefined,
      };
      setMembers(prev => [...prev, newMember]);
      showToast(`Added ${formName.trim()} to the family directory!`);
    }

    setIsModalOpen(false);
  };

  // Delete Member Trigger
  const handleDeleteTrigger = (id: string, name: string) => {
    setDeleteConfirmation({ id, name });
  };

  // Actual Delete Member Execution
  const executeDelete = () => {
    if (!deleteConfirmation) return;
    const { id, name } = deleteConfirmation;
    setMembers(prev => {
      // Remove and also clean parent/spouse references to this ID
      return prev.filter(m => m.id !== id).map(m => {
        const updated = { ...m };
        if (updated.spouseId === id) delete updated.spouseId;
        if (updated.fatherId === id) delete updated.fatherId;
        if (updated.motherId === id) delete updated.motherId;
        return updated;
      });
    });
    showToast(`Removed ${name} from directory`, 'info');
    setDeleteConfirmation(null);
  };

  // Helper for initials avatar
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .filter(n => n.length > 0 && !n.startsWith('('))
      .map(n => n[0])
      .slice(0, 2)
      .join('')
      .toUpperCase() || 'FM';
  };

  // Combine parent search query and local search query
  const query = (appSearchQuery || localSearch).toLowerCase();

  // Filter & sort members list
  const filteredMembers = members
    .filter(m => {
      const matchesSearch = !query || 
        m.name.toLowerCase().includes(query) ||
        m.relation.toLowerCase().includes(query) ||
        (m.location && m.location.toLowerCase().includes(query)) ||
        (m.bio && m.bio.toLowerCase().includes(query));

      const matchesRelation = selectedRelation === 'All' || m.relation === selectedRelation;
      const matchesStatus = selectedStatus === 'All' || 
        (selectedStatus === 'Alive' && m.isAlive) || 
        (selectedStatus === 'Deceased' && !m.isAlive);

      return matchesSearch && matchesRelation && matchesStatus;
    })
    .sort((a, b) => {
      let comparison = 0;
      if (sortBy === 'name') {
        comparison = a.name.localeCompare(b.name);
      } else if (sortBy === 'birthYear') {
        const valA = a.birthYear || 0;
        const valB = b.birthYear || 0;
        comparison = valA - valB;
      }
      return sortOrder === 'asc' ? comparison : -comparison;
    });

  // Calculate high-level stats
  const totalCount = members.length;
  const aliveCount = members.filter(m => m.isAlive).length;
  const deceasedCount = totalCount - aliveCount;
  const uniqueLocations = Array.from(new Set(members.map(m => m.location).filter(Boolean))).length;

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed top-4 right-4 z-50 animate-bounce flex items-center gap-2.5 bg-slate-900 text-white px-5 py-3.5 rounded-2xl shadow-2xl border border-slate-800">
          <Check className={`w-4 h-4 ${toast.type === 'error' ? 'text-red-400' : 'text-amber-400'}`} />
          <span className="font-sans text-xs font-bold">{toast.message}</span>
        </div>
      )}

      {/* Stats Cards Section */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200/80 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-slate-100 rounded-xl text-slate-700">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <p className="font-sans text-[10px] text-slate-400 font-bold uppercase tracking-wider">Registered</p>
              <h3 className="font-sans text-lg font-black text-slate-900">{totalCount} Members</h3>
            </div>
          </div>
        </div>

        <div className="bg-white border border-slate-200/80 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-green-50 rounded-xl text-green-600">
              <Heart className="w-4 h-4 fill-green-500/10" />
            </div>
            <div>
              <p className="font-sans text-[10px] text-slate-400 font-bold uppercase tracking-wider">Living Relative</p>
              <h3 className="font-sans text-lg font-black text-slate-900">{aliveCount} Active</h3>
            </div>
          </div>
        </div>

        <div className="bg-white border border-slate-200/80 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-50 rounded-xl text-amber-600">
              <Heart className="w-4 h-4 text-amber-500/60" />
            </div>
            <div>
              <p className="font-sans text-[10px] text-slate-400 font-bold uppercase tracking-wider">In Remembrance</p>
              <h3 className="font-sans text-lg font-black text-slate-900">{deceasedCount} Ancestors</h3>
            </div>
          </div>
        </div>

        <div className="bg-white border border-slate-200/80 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-blue-50 rounded-xl text-blue-600">
              <MapPin className="w-4 h-4" />
            </div>
            <div>
              <p className="font-sans text-[10px] text-slate-400 font-bold uppercase tracking-wider">Spread Across</p>
              <h3 className="font-sans text-lg font-black text-slate-900">{uniqueLocations} Locations</h3>
            </div>
          </div>
        </div>
      </div>

      {/* Search, Filter & Action Bar */}
      <div className="bg-white border border-slate-200/80 rounded-3xl p-5 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row gap-3 items-stretch justify-between">
          
          {/* Inner Search Field */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search directory by name, town, or relation..."
              value={appSearchQuery ? '' : localSearch}
              disabled={!!appSearchQuery}
              onChange={(e) => setLocalSearch(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200/80 rounded-xl pl-10 pr-4 py-2.5 font-sans text-xs font-semibold text-slate-700 placeholder-slate-400 outline-none focus:border-amber-400 focus:bg-white transition-all"
            />
            {appSearchQuery && (
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[9px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded border border-amber-100">
                Filtered by Header
              </span>
            )}
          </div>

          <div className="flex flex-wrap gap-2">
            {/* Sort Dropdown */}
            <div className="flex items-center bg-slate-50 border border-slate-200/80 rounded-xl px-2">
              <ArrowUpDown className="w-3.5 h-3.5 text-slate-400 mr-1.5" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as 'name' | 'birthYear')}
                className="bg-transparent text-slate-600 text-xs font-bold py-2 outline-none cursor-pointer font-sans"
              >
                <option value="name">Sort by Name</option>
                <option value="birthYear">Sort by Birth Year</option>
              </select>
              <button
                onClick={() => setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc')}
                className="p-1.5 hover:bg-slate-200/60 rounded text-slate-500 font-bold ml-1 text-[11px]"
                title="Toggle direction"
              >
                {sortOrder.toUpperCase()}
              </button>
            </div>

            {/* Add Member CTA */}
            <button
              onClick={handleOpenAdd}
              className="px-4 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-sans text-xs font-black rounded-xl flex items-center gap-2 cursor-pointer shadow-sm transition-all"
            >
              <UserPlus className="w-4 h-4" />
              <span>Add Member</span>
            </button>
          </div>

        </div>

        {/* Detailed Filters (Pills) */}
        <div className="flex flex-wrap gap-2.5 items-center pt-2 border-t border-slate-100">
          <div className="flex items-center gap-1.5 text-slate-400 text-[10px] font-sans font-bold uppercase tracking-wider">
            <Filter className="w-3.5 h-3.5 text-slate-500" />
            <span>Category:</span>
          </div>

          <select
            value={selectedRelation}
            onChange={(e) => setSelectedRelation(e.target.value)}
            className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 text-slate-600 text-[11px] font-bold rounded-lg outline-none cursor-pointer font-sans"
          >
            <option value="All">All Relations</option>
            {RELATION_OPTIONS.map(opt => (
              <option key={opt} value={opt}>{opt}</option>
            ))}
          </select>

          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value as any)}
            className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 text-slate-600 text-[11px] font-bold rounded-lg outline-none cursor-pointer font-sans"
          >
            <option value="All">All Statuses</option>
            <option value="Alive">Living Relatives</option>
            <option value="Deceased">In Remembrance</option>
          </select>

          {(selectedRelation !== 'All' || selectedStatus !== 'All' || localSearch || appSearchQuery) && (
            <button
              onClick={() => {
                setSelectedRelation('All');
                setSelectedStatus('All');
                setLocalSearch('');
              }}
              className="px-2.5 py-1.5 text-xs text-amber-600 hover:text-amber-700 hover:underline font-sans font-bold flex items-center gap-1"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Directory Grid Layout */}
      {filteredMembers.length === 0 ? (
        <div className="bg-white border border-slate-200/80 rounded-3xl p-12 text-center shadow-xs max-w-lg mx-auto">
          <Users className="w-10 h-10 text-slate-300 mx-auto mb-4" />
          <h3 className="font-serif text-base font-bold text-slate-800">No relatives match filters</h3>
          <p className="font-sans text-xs text-slate-500 mt-1.5 leading-relaxed">
            Try adjusting your search query, selecting different relation groups, or register a new relative node onto the family database.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredMembers.map((member) => {
            const initials = getInitials(member.name);
            return (
              <div
                key={member.id}
                className="bg-white border border-slate-200/80 rounded-3xl p-5 hover:shadow-md transition-all duration-300 flex flex-col justify-between relative group"
              >
                {/* Header Information */}
                <div className="space-y-4">
                  <div className="flex gap-4">
                    {/* Initials Avatar Badge */}
                    <div className="w-14 h-14 rounded-full overflow-hidden shrink-0 border border-slate-100 bg-slate-50 relative select-none">
                      {member.avatar ? (
                        <img 
                          src={member.avatar} 
                          alt={member.name} 
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover" 
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-amber-100 to-amber-200/60 text-amber-800 font-sans font-black text-sm uppercase">
                          {initials}
                        </div>
                      )}
                      <span className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white ${
                        member.isAlive ? 'bg-green-500' : 'bg-slate-400'
                      }`} />
                    </div>

                    {/* Member Identity & Relationship */}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-start justify-between gap-1.5">
                        <h4 className="font-serif text-sm font-extrabold text-slate-900 truncate leading-tight">
                          {member.name}
                        </h4>
                        
                        <div className="flex items-center gap-1 shrink-0 md:opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                          <button
                            onClick={() => handleOpenEdit(member)}
                            className="p-1 rounded-md text-slate-400 hover:text-slate-800 hover:bg-slate-50 cursor-pointer"
                            title="Edit details"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteTrigger(member.id, member.name)}
                            className="p-1 rounded-md text-slate-400 hover:text-red-500 hover:bg-red-50 cursor-pointer"
                            title="Remove member"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 mt-1">
                        <span className="font-sans text-[9px] bg-amber-500/10 text-amber-700 px-2 py-0.5 rounded-md font-black uppercase tracking-wider">
                          {member.relation}
                        </span>
                        {!member.isAlive && (
                          <span className="font-sans text-[9px] bg-amber-500/20 text-amber-800 px-2 py-0.5 rounded-md font-bold uppercase tracking-wider flex items-center gap-1 border border-amber-500/30 animate-pulse">
                            🪔 Diya Tribute
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Biography (If present) */}
                  {member.bio ? (
                    <div className="bg-slate-50 border border-slate-100/80 rounded-2xl p-3 flex gap-2.5 items-start">
                      <BookOpen className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                      <p className="font-sans text-[11px] text-slate-600 leading-normal italic">
                        "{member.bio}"
                      </p>
                    </div>
                  ) : (
                    <div className="h-0" />
                  )}

                  {/* Contact details list */}
                  <div className="space-y-1.5 pt-3 border-t border-slate-100 text-[11px] font-medium text-slate-600 font-sans">
                    {member.birthYear && (
                      <div className="flex items-center gap-2">
                        <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>Born: <strong className="text-slate-800 font-mono text-[10px]">{member.birthYear}</strong></span>
                      </div>
                    )}
                    {member.spouseId && (
                      <div className="flex items-center gap-2">
                        <Heart className="w-3.5 h-3.5 text-rose-400 shrink-0 fill-rose-500/20" />
                        <span>Spouse: <strong className="text-rose-600 font-bold">{members.find(m => m.id === member.spouseId)?.name || 'Linked Partner'}</strong></span>
                      </div>
                    )}
                    {member.location && (
                      <div className="flex items-center gap-2">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">Resides: <strong className="text-slate-800">{member.location}</strong></span>
                      </div>
                    )}
                    {member.email && (
                      <div className="flex items-center gap-2">
                        <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">{member.email}</span>
                      </div>
                    )}
                    {member.phone && (
                      <div className="flex items-center gap-2">
                        <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>{member.phone}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Card indicator line */}
                <div className="absolute bottom-0 left-0 right-0 h-1 rounded-b-3xl bg-slate-100 group-hover:bg-amber-400 transition-colors" />
              </div>
            );
          })}
        </div>
      )}

      {/* ADD / EDIT FAMILY MEMBER MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden border border-slate-100 flex flex-col max-h-[90vh] animate-fade-in">
            
            {/* Modal Header */}
            <div className="px-6 py-4.5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-amber-500 rounded-xl text-slate-950 shrink-0">
                  <UserPlus className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-serif text-sm font-bold text-slate-950">
                    {editingMember ? 'Edit Profile details' : 'Register New Relative'}
                  </h3>
                  <p className="font-sans text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                    {editingMember ? 'Update record in family tree registry' : 'Introduce a new branch into your shared registry'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 hover:bg-slate-200/50 rounded-full text-slate-400 hover:text-slate-600 transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Form body */}
            <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4">
              
              {/* Profile Photo Section */}
              <div className="bg-slate-50 border border-slate-150 rounded-2xl p-4 space-y-3">
                <span className="font-sans text-[10px] text-slate-500 font-black uppercase tracking-wider block">
                  Profile Photo
                </span>
                
                <div className="flex items-center gap-4">
                  {/* Photo Preview */}
                  <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-white shadow-sm bg-gradient-to-br from-amber-100 to-amber-200 flex items-center justify-center relative shrink-0 select-none">
                    {formAvatar ? (
                      <img 
                        src={formAvatar} 
                        alt="Profile preview" 
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover" 
                      />
                    ) : (
                      <span className="font-sans font-black text-amber-800 text-sm uppercase">
                        {formName ? getInitials(formName) : 'FM'}
                      </span>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex-1 space-y-1.5">
                    <div className="flex flex-wrap gap-2">
                      <label className="px-3 py-1.5 bg-slate-950 hover:bg-slate-800 text-white text-[11px] font-bold rounded-lg cursor-pointer flex items-center gap-1.5 transition-colors shadow-xs">
                        <Upload className="w-3 h-3" />
                        <span>Upload Photo</span>
                        <input 
                          type="file" 
                          accept="image/*" 
                          onChange={handleFileChange} 
                          className="hidden" 
                        />
                      </label>

                      {formAvatar && (
                        <button
                          type="button"
                          onClick={() => setFormAvatar('')}
                          className="px-3 py-1.5 border border-slate-200 hover:bg-slate-100 text-slate-600 text-[11px] font-bold rounded-lg cursor-pointer transition-colors"
                        >
                          Remove Photo
                        </button>
                      )}
                    </div>
                    <p className="font-sans text-[9px] text-slate-400 leading-normal">
                      Select any local JPG or PNG photo, or use the URL input below to link an external web image.
                    </p>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200/60">
                  <input
                    type="url"
                    placeholder="Or paste external image URL (e.g. https://images.unsplash.com/...)"
                    value={formAvatar}
                    onChange={(e) => setFormAvatar(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-[11px] font-semibold outline-none focus:border-amber-400 transition-all text-slate-800"
                  />
                </div>
              </div>

              {/* Full Name */}
              <div className="space-y-1">
                <label className="font-sans text-[10px] text-slate-500 font-black uppercase tracking-wider block">Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Suresh Kumar Nimmagadda"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none focus:border-amber-400 focus:bg-white transition-all text-slate-800"
                />
              </div>

              {/* Grid 2x2 for relation and birthYear */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Relationship / Relation */}
                <div className="space-y-1">
                  <label className="font-sans text-[10px] text-slate-500 font-black uppercase tracking-wider block">Relation in Family</label>
                  <select
                     value={formRelation}
                    onChange={(e) => setFormRelation(e.target.value as FamilyMember['relation'])}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none focus:border-amber-400 focus:bg-white transition-all text-slate-800"
                  >
                    {RELATION_OPTIONS.map(opt => (
                      <option key={opt} value={opt}>{opt}</option>
                    ))}
                  </select>
                </div>

                {/* Birth Year / Death Year Group */}
                <div className="space-y-1">
                  <label className="font-sans text-[10px] text-slate-500 font-black uppercase tracking-wider block">
                    {formIsAlive ? 'Birth Year' : 'Birth & Death Years'}
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      min="1800"
                      max="2026"
                      placeholder="Birth"
                      value={formBirthYear}
                      onChange={(e) => setFormBirthYear(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none focus:border-amber-400 focus:bg-white transition-all text-slate-800"
                    />
                    {!formIsAlive && (
                      <input
                        type="number"
                        min="1800"
                        max="2026"
                        placeholder="Death"
                        value={formDeathYear}
                        onChange={(e) => setFormDeathYear(e.target.value)}
                        className="w-full bg-slate-50 border border-amber-300 rounded-xl px-3 py-2 text-xs font-semibold outline-none focus:border-amber-400 focus:bg-white transition-all text-slate-800 shadow-sm"
                      />
                    )}
                  </div>
                </div>

              </div>

              {/* Is Alive toggle switch */}
              <div className="bg-slate-50 border border-slate-100 rounded-2xl p-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Heart className={`w-4 h-4 ${formIsAlive ? 'text-green-500 fill-green-500/10' : 'text-slate-400'}`} />
                  <div>
                    <span className="font-sans text-xs font-bold text-slate-800 block">Relative is Living</span>
                    <span className="font-sans text-[9px] text-slate-400">Turn off if this is an ancestor memorial profile</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setFormIsAlive(!formIsAlive)}
                  className={`w-11 h-6 rounded-full p-1 transition-colors duration-300 focus:outline-none cursor-pointer ${
                    formIsAlive ? 'bg-green-500' : 'bg-slate-300'
                  }`}
                >
                  <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform duration-300 ${
                    formIsAlive ? 'translate-x-5' : 'translate-x-0'
                  }`} />
                </button>
              </div>

              {/* Grid 2x2 for Email and Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Email address */}
                <div className="space-y-1">
                  <label className="font-sans text-[10px] text-slate-500 font-black uppercase tracking-wider block">Email Address</label>
                  <input
                    type="email"
                    placeholder="e.g. sita@example.com"
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none focus:border-amber-400 focus:bg-white transition-all text-slate-800"
                  />
                </div>

                {/* Phone number */}
                <div className="space-y-1">
                  <label className="font-sans text-[10px] text-slate-500 font-black uppercase tracking-wider block">Phone Number</label>
                  <input
                    type="tel"
                    placeholder="e.g. +91 98480 12345"
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none focus:border-amber-400 focus:bg-white transition-all text-slate-800"
                  />
                </div>

              </div>

              {/* Town / Location */}
              <div className="space-y-1">
                <label className="font-sans text-[10px] text-slate-500 font-black uppercase tracking-wider block">Current Location / Town</label>
                <input
                  type="text"
                  placeholder="e.g. Visakhapatnam, India"
                  value={formLocation}
                  onChange={(e) => setFormLocation(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none focus:border-amber-400 focus:bg-white transition-all text-slate-800"
                />
              </div>

              {/* Biography / Description */}
              <div className="space-y-1">
                <label className="font-sans text-[10px] text-slate-500 font-black uppercase tracking-wider block">Short Biography or Notes</label>
                <textarea
                  rows={2}
                  placeholder="Share details about their occupation, passions, or family role..."
                  value={formBio}
                  onChange={(e) => setFormBio(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none focus:border-amber-400 focus:bg-white transition-all text-slate-800"
                />
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-100 flex gap-2 justify-end">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-bold rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-black rounded-xl cursor-pointer"
                >
                  {editingMember ? 'Save Profile' : 'Add Profile'}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {deleteConfirmation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl p-6 border border-slate-100 flex flex-col space-y-4 animate-fade-in">
            <div className="flex items-center gap-3 border-b pb-3 border-slate-100">
              <div className="p-2 bg-red-100 rounded-xl text-red-600 shrink-0">
                <Trash2 className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-serif text-sm font-bold text-slate-950">Remove Family Member</h3>
                <p className="font-sans text-[10px] text-slate-400 font-bold uppercase tracking-wider">Confirm Profile Deletion</p>
              </div>
            </div>

            <div className="space-y-2">
              <p className="font-sans text-xs text-slate-600 leading-relaxed">
                Are you sure you want to remove <strong className="text-slate-900 font-bold">{deleteConfirmation.name}</strong> from the family directory?
              </p>
              <p className="font-sans text-[10px] text-slate-400 bg-slate-50 p-2.5 rounded-xl border border-slate-150 leading-relaxed">
                ⚠️ <strong className="text-slate-600">Warning:</strong> This will also automatically clean up any husband/wife or father/mother relationships linked to them in the Family Tree, ensuring lineage integrity. This action cannot be undone.
              </p>
            </div>

            <div className="flex justify-end gap-2.5 pt-2 border-t border-slate-150">
              <button
                type="button"
                onClick={() => setDeleteConfirmation(null)}
                className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-bold rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={executeDelete}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl cursor-pointer shadow-sm transition-all"
              >
                Delete Profile
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
