import { useState } from 'react';
import { Search, Menu, X, Network, Home, MessageSquare, Image, Calendar, Heart, Settings, Users } from 'lucide-react';
import { ActiveTab } from '../types';

interface HeaderProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
}

export default function Header({ searchQuery, setSearchQuery, activeTab, setActiveTab }: HeaderProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'updates' as ActiveTab, label: 'Feed', icon: Home },
    { id: 'messages' as ActiveTab, label: 'Chat', icon: MessageSquare },
    { id: 'tree' as ActiveTab, label: 'Tree', icon: Network },
    { id: 'members' as ActiveTab, label: 'Members', icon: Users },
    { id: 'gallery' as ActiveTab, label: 'Gallery', icon: Image },
    { id: 'calendar' as ActiveTab, label: 'Events', icon: Calendar },
    { id: 'memorial' as ActiveTab, label: 'Remembrance', icon: Heart },
    { id: 'settings' as ActiveTab, label: 'Registry', icon: Settings },
  ];

  return (
    <header className="bg-white border-b border-slate-200/80 sticky top-0 z-30 px-6 py-4 flex items-center justify-between gap-4">
      {/* Search Input */}
      <div className="relative max-w-md w-full flex-1">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          placeholder="Search members, announcements, events, gallery..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full bg-slate-50 border border-slate-200/80 rounded-2xl pl-10 pr-4 py-2.5 font-sans text-xs font-semibold text-slate-700 placeholder-slate-400 outline-none focus:border-amber-400 focus:bg-white transition-all shadow-xs"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 rounded-full bg-slate-100"
          >
            <X className="w-3 h-3" />
          </button>
        )}
      </div>

      {/* Brand logo (Mobile only) */}
      <div className="flex items-center gap-2 md:hidden shrink-0">
        <div className="w-8 h-8 bg-amber-500 rounded-lg flex items-center justify-center font-serif text-white font-black text-sm">
          N
        </div>
        <span className="font-serif text-slate-900 text-xs font-black tracking-tight">Family Hub</span>
      </div>

      {/* Actions / Mobile Menu Toggle */}
      <div className="flex items-center gap-2.5">
        <div className="hidden sm:flex items-center gap-2 text-right">
          <span className="font-sans text-[10px] text-slate-400 font-bold uppercase tracking-wider">Active Workspace</span>
          <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
        </div>

        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="md:hidden p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 cursor-pointer"
        >
          {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile Drawer Menu */}
      {isMobileMenuOpen && (
        <div className="absolute top-18 left-0 w-full bg-white border-b border-slate-200 shadow-xl py-4 px-6 md:hidden flex flex-col gap-2 z-50 animate-fade-in">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest pb-1">Navigation</div>
          <div className="grid grid-cols-2 gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setIsMobileMenuOpen(false);
                  }}
                  className={`flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl font-sans text-xs font-bold transition-all cursor-pointer ${
                    isActive
                      ? 'bg-amber-500 text-slate-950 shadow-sm shadow-amber-500/10'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50 border border-transparent'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </header>
  );
}
