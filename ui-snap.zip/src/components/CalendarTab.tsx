import { useState, useEffect } from 'react';
import { Calendar, Clock, MapPin, PlusCircle, Check, Users, AlertCircle } from 'lucide-react';
import { CalendarEvent } from '../types';
import { INITIAL_EVENTS } from '../data';

interface CalendarTabProps {
  searchQuery: string;
}

export default function CalendarTab({ searchQuery }: CalendarTabProps) {
  const [events, setEvents] = useState<CalendarEvent[]>(() => {
    const saved = localStorage.getItem('family_events');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return INITIAL_EVENTS;
  });

  const [isAddOpen, setIsAddOpen] = useState(false);

  // Form State
  const [formTitle, setFormTitle] = useState('');
  const [formDate, setFormDate] = useState('');
  const [formTime, setFormTime] = useState('');
  const [formType, setFormType] = useState<CalendarEvent['type']>('birthday');
  const [formDescription, setFormDescription] = useState('');
  const [formLocation, setFormLocation] = useState('');

  useEffect(() => {
    localStorage.setItem('family_events', JSON.stringify(events));
  }, [events]);

  const handleRsvp = (eventId: string, status: 'going' | 'maybe' | 'not_going') => {
    setEvents(prev => prev.map(evt => {
      if (evt.id === eventId) {
        // Find existing RSVP for active user
        const existingRsvpIndex = evt.rsvps.findIndex(r => r.memberName === 'Vijay Nimmagadda');
        let updatedRsvps = [...evt.rsvps];

        if (existingRsvpIndex > -1) {
          updatedRsvps[existingRsvpIndex] = { memberName: 'Vijay Nimmagadda', status };
        } else {
          updatedRsvps.push({ memberName: 'Vijay Nimmagadda', status });
        }

        return { ...evt, rsvps: updatedRsvps };
      }
      return evt;
    }));
  };

  const handleAddEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formDate) return;

    const newEvent: CalendarEvent = {
      id: 'evt-' + Date.now(),
      title: formTitle.trim(),
      date: formDate,
      time: formTime.trim() || undefined,
      type: formType,
      description: formDescription.trim() || undefined,
      location: formLocation.trim() || undefined,
      rsvps: [{ memberName: 'Vijay Nimmagadda', status: 'going' }]
    };

    setEvents(prev => [...prev, newEvent].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()));
    setIsAddOpen(false);

    // Reset Form
    setFormTitle('');
    setFormDate('');
    setFormTime('');
    setFormType('birthday');
    setFormDescription('');
    setFormLocation('');
  };

  const filteredEvents = events.filter(evt =>
    evt.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (evt.description && evt.description.toLowerCase().includes(searchQuery.toLowerCase())) ||
    (evt.location && evt.location.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const getEventBadgeColor = (type: CalendarEvent['type']) => {
    switch (type) {
      case 'birthday': return 'bg-sky-50 text-sky-600 border-sky-150';
      case 'anniversary': return 'bg-amber-50 text-amber-600 border-amber-150';
      case 'reunion': return 'bg-rose-50 text-rose-600 border-rose-150';
      default: return 'bg-slate-50 text-slate-600 border-slate-150';
    }
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Banner */}
      <div className="bg-white border border-outline-variant/30 rounded-3xl p-6 sm:p-8 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="space-y-1.5 max-w-xl">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-sky-50 rounded-xl text-sky-600 border border-sky-200/50">
              <Calendar className="w-5 h-5" />
            </span>
            <span className="font-sans text-[10px] font-black uppercase tracking-widest text-sky-600 bg-sky-50 px-2.5 py-1 rounded-md">Event Planner</span>
          </div>
          <h2 className="font-serif text-2xl font-black text-gray-900 tracking-tight">Shared Family Calendar</h2>
          <p className="font-sans text-xs text-on-surface-variant leading-relaxed">
            Stay in sync regarding upcoming milestones, birthday celebrations, reunions, and prayer ceremonies. RSVP easily to help coordination.
          </p>
        </div>
        <button
          onClick={() => setIsAddOpen(true)}
          className="w-full md:w-auto px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-sans text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 shadow-md transition-all cursor-pointer shrink-0"
        >
          <PlusCircle className="w-4 h-4 text-amber-400" />
          <span>Schedule Event</span>
        </button>
      </div>

      {/* Events List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredEvents.map((evt) => {
          const myRsvp = evt.rsvps.find(r => r.memberName === 'Vijay Nimmagadda')?.status;
          const goingCount = evt.rsvps.filter(r => r.status === 'going').length;

          return (
            <div key={evt.id} className="bg-white border border-outline-variant/30 rounded-3xl p-6 shadow-xs hover:border-slate-300 transition-all flex flex-col justify-between space-y-4">
              
              <div className="space-y-3.5">
                {/* Badge & Date Ribbon */}
                <div className="flex items-center justify-between">
                  <span className={`px-2.5 py-0.5 rounded-full text-[8px] font-black uppercase tracking-wider border ${getEventBadgeColor(evt.type)}`}>
                    {evt.type}
                  </span>
                  <span className="font-mono text-[10px] font-bold text-slate-400 bg-slate-50 px-2.5 py-1 rounded-md border border-slate-100">
                    {evt.date}
                  </span>
                </div>

                {/* Info block */}
                <div className="space-y-1.5">
                  <h3 className="font-serif text-base font-black text-slate-900 leading-snug">{evt.title}</h3>
                  {evt.description && (
                    <p className="font-sans text-xs text-slate-500 font-medium leading-relaxed">{evt.description}</p>
                  )}
                </div>

                {/* Metadata details */}
                <div className="flex flex-col gap-1.5 pt-1 text-xs text-slate-600 font-semibold">
                  {evt.time && (
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{evt.time}</span>
                    </span>
                  )}
                  {evt.location && (
                    <span className="flex items-center gap-1.5 truncate">
                      <MapPin className="w-3.5 h-3.5 text-red-400 shrink-0" />
                      <span>{evt.location}</span>
                    </span>
                  )}
                </div>
              </div>

              {/* RSVP Actions Panel */}
              <div className="pt-4 border-t border-slate-100 space-y-4">
                <div className="flex items-center justify-between text-[11px] text-slate-500 font-bold uppercase tracking-wider">
                  <span className="flex items-center gap-1">
                    <Users className="w-4 h-4 text-slate-400" />
                    <span>{goingCount} Going</span>
                  </span>
                  <span>Your RSVP: {myRsvp ? <span className="text-amber-600 font-black">{myRsvp}</span> : <span className="text-slate-400 font-black">None</span>}</span>
                </div>

                {/* RSVP Options */}
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => handleRsvp(evt.id, 'going')}
                    className={`py-2 rounded-xl text-[10px] font-extrabold uppercase transition-all cursor-pointer border ${
                      myRsvp === 'going'
                        ? 'bg-emerald-500 text-white border-emerald-500 font-black'
                        : 'bg-white border-slate-200 hover:bg-emerald-50 hover:text-emerald-600 text-slate-500'
                    }`}
                  >
                    Going
                  </button>
                  <button
                    onClick={() => handleRsvp(evt.id, 'maybe')}
                    className={`py-2 rounded-xl text-[10px] font-extrabold uppercase transition-all cursor-pointer border ${
                      myRsvp === 'maybe'
                        ? 'bg-amber-500 text-slate-950 border-amber-500 font-black'
                        : 'bg-white border-slate-200 hover:bg-amber-50 hover:text-amber-600 text-slate-500'
                    }`}
                  >
                    Maybe
                  </button>
                  <button
                    onClick={() => handleRsvp(evt.id, 'not_going')}
                    className={`py-2 rounded-xl text-[10px] font-extrabold uppercase transition-all cursor-pointer border ${
                      myRsvp === 'not_going'
                        ? 'bg-slate-900 text-white border-slate-900 font-black'
                        : 'bg-white border-slate-200 hover:bg-rose-50 hover:text-rose-600 text-slate-500'
                    }`}
                  >
                    No
                  </button>
                </div>
              </div>

            </div>
          );
        })}

        {filteredEvents.length === 0 && (
          <div className="col-span-full text-center py-20 bg-white border border-dashed border-slate-200 rounded-3xl p-6 text-slate-400">
            <AlertCircle className="w-8 h-8 mx-auto text-slate-300 mb-2" />
            <span className="font-sans text-xs font-semibold">No planned family events match your filters.</span>
          </div>
        )}
      </div>

      {/* SCHEDULE EVENT MODAL */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden border border-slate-100 flex flex-col max-h-[90vh] animate-fade-in">
            
            <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <div className="flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-sky-500" />
                <h3 className="font-serif text-base font-bold text-gray-900">Schedule Family Event</h3>
              </div>
              <button 
                onClick={() => setIsAddOpen(false)}
                className="p-1.5 rounded-full hover:bg-slate-200 text-slate-500 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddEvent} className="p-6 space-y-4">
              
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Event Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Amma's Birthday Dinner"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-4 py-2.5 text-xs font-medium outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Event Date *</label>
                  <input
                    type="date"
                    required
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-4 py-2.5 text-xs font-medium outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Time / Hour</label>
                  <input
                    type="text"
                    placeholder="e.g. 07:00 PM onwards"
                    value={formTime}
                    onChange={(e) => setFormTime(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-4 py-2.5 text-xs font-medium outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Event Type</label>
                  <select
                    value={formType}
                    onChange={(e) => setFormType(e.target.value as CalendarEvent['type'])}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-3 py-2.5 text-xs font-medium outline-none"
                  >
                    <option value="birthday">Birthday Celebration</option>
                    <option value="anniversary">Anniversary</option>
                    <option value="reunion">Family Reunion Gathering</option>
                    <option value="other">Other Gathering</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Location / Link</label>
                  <input
                    type="text"
                    placeholder="e.g. Visakhapatnam garden / Zoom room"
                    value={formLocation}
                    onChange={(e) => setFormLocation(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-4 py-2.5 text-xs font-medium outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide">Description Notes</label>
                <textarea
                  rows={3}
                  placeholder="Share dress code, gift ideas, or agenda items..."
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl px-4 py-2.5 text-xs font-medium outline-none resize-none"
                />
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-sans text-xs font-bold rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-sans text-xs font-bold rounded-xl cursor-pointer flex items-center gap-1"
                >
                  <Check className="w-3.5 h-3.5 text-amber-400" />
                  <span>Create Event</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}

// Minimal placeholder Close icon
function X(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <line x1="18" y1="6" x2="6" y2="18"></line>
      <line x1="6" y1="6" x2="18" y2="18"></line>
    </svg>
  );
}
