import { useState, useEffect } from 'react';
import { MessageCircle, Check, Flame, AlertCircle, Award, BookOpen } from 'lucide-react';
import { Ancestor } from '../types';

interface MemorialTabProps {
  searchQuery: string;
}

export default function MemorialTab({ searchQuery }: MemorialTabProps) {
  const [ancestors, setAncestors] = useState<Ancestor[]>(() => {
    const saved = localStorage.getItem('family_ancestors_list');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    // Default starting list
    return [];
  });

  const [selectedAncestorId, setSelectedAncestorId] = useState<string | null>(() => {
    const saved = localStorage.getItem('family_ancestors_list');
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as Ancestor[];
        if (parsed && parsed.length > 0) return parsed[0].id;
      } catch (e) {
        console.error(e);
      }
    }
    return null;
  });
  const [newTribute, setNewTribute] = useState('');
  const [newTributeAuthor, setNewTributeAuthor] = useState('Vijay Nimmagadda');

  useEffect(() => {
    localStorage.setItem('family_ancestors_list', JSON.stringify(ancestors));
  }, [ancestors]);

  const handleLightCandle = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setAncestors(prev => prev.map(anc => {
      if (anc.id === id) return { ...anc, candleCount: anc.candleCount + 1 };
      return anc;
    }));
  };

  const handleAddTribute = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAncestorId || !newTribute.trim()) return;

    setAncestors(prev => prev.map(anc => {
      if (anc.id === selectedAncestorId) {
        return {
          ...anc,
          tributes: [
            ...anc.tributes,
            {
              id: 'tribute-' + Date.now(),
              author: newTributeAuthor.trim() || 'Vijay Nimmagadda',
              text: newTribute.trim(),
              date: new Date().toISOString().split('T')[0]
            }
          ]
        };
      }
      return anc;
    }));

    setNewTribute('');
  };

  const filteredAncestors = ancestors.filter(anc =>
    anc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    anc.role.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const selectedAncestor = ancestors.find(a => a.id === selectedAncestorId) || null;

  return (
    <div className="space-y-8 pb-16">
      {/* Banner */}
      <div className="bg-slate-950 border border-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-6 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-64 h-64 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="space-y-1.5 max-w-xl relative z-10">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-amber-500/10 rounded-xl text-amber-400 border border-amber-500/20">
              <Flame className="w-5 h-5 animate-pulse" />
            </span>
            <span className="font-sans text-[10px] font-black uppercase tracking-widest text-amber-400 bg-amber-500/15 px-2.5 py-1 rounded-md">Memory Portal</span>
          </div>
          <h2 className="font-serif text-2xl font-black text-slate-100 tracking-tight">Remembered Ancestors</h2>
          <p className="font-sans text-xs text-slate-400 leading-relaxed">
            Honoring the paths cleared before us. Light a virtual candle in eternal remembrance, review milestones, and append heartfelt tributes to our collective memory wall.
          </p>
        </div>
      </div>

      {/* Grid: Ancestors Directory on Left, Memory Wall Detail on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Ancestors Directory */}
        <div className="lg:col-span-1 space-y-4">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Ancestry Directory</div>
          <div className="space-y-3">
            {filteredAncestors.map((anc) => {
              const isSelected = selectedAncestorId === anc.id;
              return (
                <div
                  key={anc.id}
                  onClick={() => setSelectedAncestorId(anc.id)}
                  className={`p-5 rounded-2xl border transition-all cursor-pointer flex flex-col gap-3.5 relative overflow-hidden ${
                    isSelected
                      ? 'bg-slate-900 border-slate-900 text-slate-100 shadow-lg'
                      : 'bg-white border-slate-200/80 hover:border-slate-300 text-slate-800'
                  }`}
                >
                  <div className="flex justify-between items-start gap-2">
                    <div>
                      <h3 className="font-serif text-sm font-black tracking-tight">{anc.name}</h3>
                      <p className={`font-sans text-[10px] font-bold tracking-wide mt-0.5 ${isSelected ? 'text-amber-400' : 'text-slate-500'}`}>{anc.role}</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] pt-2 border-t border-slate-100/10">
                    <span className="font-mono font-bold text-slate-400">{anc.birthYear} – {anc.deathYear}</span>
                    <button
                      onClick={(e) => handleLightCandle(anc.id, e)}
                      className="px-2.5 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-500 border border-amber-500/20 hover:border-amber-500/30 rounded-xl flex items-center gap-1 font-sans text-[9px] font-black uppercase transition-all hover:scale-105 cursor-pointer"
                    >
                      <Flame className="w-3.5 h-3.5 fill-amber-500 animate-pulse" />
                      <span>{anc.candleCount} lit</span>
                    </button>
                  </div>
                </div>
              );
            })}

            {filteredAncestors.length === 0 && (
              <div className="text-center py-12 bg-white border border-dashed border-slate-200 rounded-3xl p-6 text-slate-400">
                <AlertCircle className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                <span className="font-sans text-xs font-semibold">No family ancestors match search filters.</span>
              </div>
            )}
          </div>
        </div>

        {/* Tribute Details Panel */}
        <div className="lg:col-span-2">
          {selectedAncestor ? (
            <div className="bg-white border border-outline-variant/30 rounded-3xl p-6 sm:p-8 shadow-xs space-y-6">
              
              {/* Header */}
              <div className="border-b border-slate-100 pb-5 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h3 className="font-serif text-xl font-black text-slate-900 leading-none">{selectedAncestor.name}</h3>
                    <p className="font-sans text-xs text-amber-600 font-extrabold mt-1.5">{selectedAncestor.role}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-slate-400 bg-slate-50 px-2.5 py-1.5 rounded-lg border border-slate-100">
                      {selectedAncestor.birthYear} – {selectedAncestor.deathYear}
                    </span>
                    <button
                      onClick={(e) => handleLightCandle(selectedAncestor.id, e)}
                      className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-amber-400 font-sans text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all cursor-pointer hover:scale-105"
                    >
                      <Flame className="w-4 h-4 text-amber-400 animate-pulse fill-amber-400" />
                      <span>Light Tribute Candle ({selectedAncestor.candleCount})</span>
                    </button>
                  </div>
                </div>

                <div className="bg-amber-50/50 border border-amber-200/40 p-4 rounded-2xl italic font-serif text-xs text-amber-900 leading-relaxed text-center relative">
                  <span className="absolute left-2 top-0 font-serif text-3xl text-amber-300 pointer-events-none">“</span>
                  "{selectedAncestor.quote}"
                  <span className="absolute right-2 bottom-0 font-serif text-3xl text-amber-300 pointer-events-none">”</span>
                </div>
              </div>

              {/* Biography Section */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-slate-700">
                  <BookOpen className="w-4 h-4 text-slate-400" />
                  <h4 className="font-sans text-xs font-black uppercase tracking-wider">Biography</h4>
                </div>
                <p className="font-sans text-xs text-slate-600 leading-relaxed">{selectedAncestor.bio}</p>
              </div>

              {/* Achievements list */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center gap-2 text-slate-700">
                  <Award className="w-4 h-4 text-slate-400" />
                  <h4 className="font-sans text-xs font-black uppercase tracking-wider">Key Family Contributions</h4>
                </div>
                <ul className="space-y-2 text-xs font-semibold text-slate-600 list-disc list-inside">
                  {selectedAncestor.achievements.map((ach, i) => (
                    <li key={i} className="leading-relaxed">{ach}</li>
                  ))}
                </ul>
              </div>

              {/* Tributes Section */}
              <div className="border-t border-slate-100 pt-5 space-y-4">
                <div className="flex items-center gap-2 text-slate-700">
                  <MessageCircle className="w-4 h-4 text-slate-400" />
                  <h4 className="font-sans text-xs font-black uppercase tracking-wider">Tributes Wall ({selectedAncestor.tributes.length})</h4>
                </div>

                <div className="space-y-3.5 max-h-56 overflow-y-auto pr-1">
                  {selectedAncestor.tributes.map((trib) => (
                    <div key={trib.id} className="p-4 bg-slate-50 border border-slate-100 rounded-2xl space-y-1.5 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-800">{trib.author}</span>
                        <span className="text-[9px] text-slate-400">{trib.date}</span>
                      </div>
                      <p className="text-slate-600 font-medium italic leading-relaxed">"{trib.text}"</p>
                    </div>
                  ))}

                  {selectedAncestor.tributes.length === 0 && (
                    <div className="text-center py-6 text-slate-400 text-xs font-medium bg-slate-50/50 border border-dashed border-slate-200 rounded-2xl p-4">
                      No tributes posted yet. Be the first to leave a warm thought.
                    </div>
                  )}
                </div>

                {/* Add Tribute Form */}
                <form onSubmit={handleAddTribute} className="space-y-3 pt-2">
                  <div className="flex gap-3">
                    <input
                      type="text"
                      placeholder="Your Name"
                      value={newTributeAuthor}
                      onChange={(e) => setNewTributeAuthor(e.target.value)}
                      className="w-1/3 bg-slate-50 border border-slate-200/80 focus:border-amber-400 rounded-xl px-3 py-2 text-xs font-medium outline-none"
                    />
                    <input
                      type="text"
                      required
                      placeholder="Write a loving tribute, memory, or prayer..."
                      value={newTribute}
                      onChange={(e) => setNewTribute(e.target.value)}
                      className="flex-1 bg-slate-50 border border-slate-200/80 focus:border-amber-400 rounded-xl px-4 py-2 text-xs font-medium outline-none"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-sans text-xs font-bold rounded-xl cursor-pointer transition-all shrink-0 flex items-center gap-1"
                    >
                      <Check className="w-3.5 h-3.5 text-amber-400" />
                      <span>Post</span>
                    </button>
                  </div>
                </form>
              </div>

            </div>
          ) : (
            <div className="text-center py-20 bg-white border border-slate-200 rounded-3xl p-6 text-slate-400">
              <BookOpen className="w-8 h-8 mx-auto text-slate-300 mb-2" />
              <span className="font-sans text-xs font-semibold">Select an ancestor from the left listing to review detailed bio archives.</span>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
