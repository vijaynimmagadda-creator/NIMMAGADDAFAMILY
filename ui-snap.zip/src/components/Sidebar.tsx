import { Home, MessageSquare, Image, Calendar, Settings, Heart, Network, Users } from 'lucide-react';
import { ActiveTab } from '../types';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
}

export default function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  const navItems = [
    { id: 'updates' as ActiveTab, label: 'Updates Feed', icon: Home },
    { id: 'messages' as ActiveTab, label: 'Family Chat', icon: MessageSquare },
    { id: 'tree' as ActiveTab, label: 'Family Tree', icon: Network },
    { id: 'members' as ActiveTab, label: 'Members Directory', icon: Users },
    { id: 'gallery' as ActiveTab, label: 'Photo Gallery', icon: Image },
    { id: 'calendar' as ActiveTab, label: 'Calendar Events', icon: Calendar },
    { id: 'memorial' as ActiveTab, label: 'Memory Wall', icon: Heart },
    { id: 'settings' as ActiveTab, label: 'Hub Registry', icon: Settings },
  ];

  return (
    <aside className="w-64 bg-slate-900 text-slate-400 min-h-screen hidden md:flex flex-col border-r border-slate-800 relative z-10 shrink-0">
      {/* Brand Header */}
      <div className="p-6 border-b border-slate-800 flex items-center gap-3">
        <div className="w-9 h-9 bg-gradient-to-tr from-amber-500 to-amber-600 rounded-xl flex items-center justify-center shadow-lg shadow-amber-500/10 shrink-0">
          <span className="font-serif text-white font-black text-lg select-none">N</span>
        </div>
        <div>
          <h1 className="font-serif text-slate-100 text-sm font-black tracking-tight leading-tight">Nimmagadda</h1>
          <p className="font-sans text-[10px] text-slate-500 font-bold uppercase tracking-wider">Family Hub</p>
        </div>
      </div>

      {/* Nav Link List */}
      <nav className="flex-1 px-4 py-6 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3.5 px-4 py-3 rounded-xl font-sans text-xs font-bold tracking-wide transition-all cursor-pointer ${
                isActive
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/10'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Footer Info */}
      <div className="p-6 border-t border-slate-800 text-[10px] text-slate-600 font-sans font-semibold space-y-1">
        <p>© 2026 Nimmagadda Hub</p>
        <p>Keeping archives secure</p>
      </div>
    </aside>
  );
}
